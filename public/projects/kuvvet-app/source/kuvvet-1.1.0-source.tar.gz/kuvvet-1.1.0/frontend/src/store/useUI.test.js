// @vitest-environment happy-dom
// useUI pulls in api.js, which reads navigator.userAgent at module scope.
import { describe, expect, it, beforeEach, afterEach, vi } from 'vitest'
import { useUI } from './useUI.js'

// "Off" has to hold at the timer itself, not at the four places that start one — the same
// reason the rest-after-a-set rule is a shared condition rather than four copies.
describe('rest timer set to Off', () => {
  beforeEach(() => { vi.useFakeTimers(); useUI.setState({ timer: null }) })
  afterEach(() => { useUI.getState().stopRest(); vi.useRealTimers() })

  it('starts nothing', () => {
    useUI.getState().startRest(0)
    expect(useUI.getState().timer).toBe(null)
  })

  it('stops a rest that is already running', () => {
    useUI.getState().startRest(90)
    expect(useUI.getState().timer).not.toBe(null)
    useUI.getState().startRest(0)
    expect(useUI.getState().timer).toBe(null)
  })

  it('still runs for a real duration', () => {
    useUI.getState().startRest(90)
    expect(useUI.getState().timer.total).toBe(90)
  })
})

describe('monetization runtime state', () => {
  it('starts deny-by-default and merges a native consent result', () => {
    useUI.getState().resetMonetization()
    expect(useUI.getState().monetization.canRequestAds).toBe(null)
    expect(useUI.getState().monetization.initialized).toBe(false)
    useUI.getState().setMonetization({ initialized: true, available: true, configured: true, canRequestAds: true })
    expect(useUI.getState().monetization).toMatchObject({
      initialized: true,
      available: true,
      configured: true,
      canRequestAds: true,
      privacyOptionsRequired: false,
    })
  })
})
