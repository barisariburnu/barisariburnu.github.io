// @vitest-environment happy-dom
import React, { act } from 'react'
import { createRoot } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import Media, { Thumb } from './Media.jsx'

vi.mock('../store/useStore.js', () => ({
  useStore: selector => selector({ S: { gifSize: 'full' }, update: vi.fn() }),
}))
vi.mock('../lib/i18n.js', () => ({
  t: key => key,
  exerciseNameFor: ex => ex.n,
}))

globalThis.IS_REACT_ACT_ENVIRONMENT = true

let container
let root

beforeEach(() => {
  container = document.createElement('div')
  document.body.appendChild(container)
  root = createRoot(container)
})

afterEach(() => {
  act(() => root.unmount())
  container.remove()
})

const fail = image => act(() => image.dispatchEvent(new Event('error', { bubbles: true })))

describe('licensed publisher-hosted exercise media', () => {
  it('loads the matching publisher thumbnail and then the icon fallback', () => {
    act(() => root.render(<Thumb ex={{ img: 'exercise.jpg' }} />))
    expect(container.querySelector('img').getAttribute('src')).toBe('https://barisariburnu.com.tr/projects/kuvvet-app/jpg/exercise.jpg')

    fail(container.querySelector('img'))
    expect(container.querySelector('.thumb-x')).toBeTruthy()
  })

  it('falls back from the publisher animation to its matching still and then accessibly', () => {
    act(() => root.render(<Media ex={{ n: 'Squat', img: 'exercise.jpg', gif: 'exercise.gif' }} />))
    expect(container.querySelector('img').getAttribute('src')).toBe('https://barisariburnu.com.tr/projects/kuvvet-app/gif/exercise.gif')

    fail(container.querySelector('img'))
    expect(container.querySelector('img').getAttribute('src')).toBe('https://barisariburnu.com.tr/projects/kuvvet-app/jpg/exercise.jpg')
    fail(container.querySelector('img'))
    expect(container.querySelector('.exmedia-fallback').textContent).toContain('Media unavailable')
  })
})
