import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { adsAvailable, hideBanner, initializeAds, showBanner, subscribeAdsRuntime } from '../lib/ads.js'
import { adDecision, surfaceForPath } from '../lib/monetization.js'
import { useUI } from '../store/useUI.js'

// Native owns the banner view, so this coordinator intentionally renders no web placeholder.
// A failed/denied request therefore cannot leave a blank strip or shift the React layout.
export default function AdSlot() {
  const location = useLocation()
  const monetization = useUI(state => state.monetization)
  const tier = useUI(state => state.entitlement?.tier || 'free')
  const setMonetization = useUI(state => state.setMonetization)

  useEffect(() => {
    let live = true
    const unsubscribe = subscribeAdsRuntime(next => { if (live) setMonetization(next) })
    initializeAds().then(next => { if (live) setMonetization(next) })
    return () => { live = false; unsubscribe(); hideBanner() }
  }, [setMonetization])

  useEffect(() => {
    let live = true
    const surface = surfaceForPath(location.pathname)
    const decision = adDecision({
      surface,
      tier,
      isNativeAndroid: adsAvailable(),
      ...monetization,
    })
    ;(async () => {
      if (!decision.show) return hideBanner()
      const result = await showBanner(surface)
      if (!live || result?.visible) return
      await hideBanner()
    })()
    return () => { live = false }
  }, [location.pathname, monetization, tier])

  return null
}
