import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { t } from '../lib/i18n.js'
import {
  billingAccountReference,
  initializeBilling,
  listPlans,
  manageSubscription,
  onPurchaseUpdated,
  purchasePlan,
  refreshEntitlement,
  restorePurchases,
  verifyPurchases
} from '../lib/billing.js'
import { useUI } from '../store/useUI.js'
import { useStore } from '../store/useStore.js'
import Icon from '../components/Icon.jsx'
import BrandMark from '../components/BrandMark.jsx'

const PERIODS = {
  P1M: { label: 'Monthly', unit: 'month' },
  P1Y: { label: 'Annual', unit: 'year' }
}

const BENEFITS = [
  {
    capability: 'ad_free',
    title: 'No ads on any screen',
    detail: 'Free accounts may see a quiet banner on Library, Plan and Stats. Workouts stay ad-free.'
  },
  { capability: 'cloud_backup', title: 'Managed cloud backup', detail: 'Recover your training data across supported devices.' },
  { capability: 'cloud_sync', title: 'Sync across your devices', detail: 'Continue with the same history on your other devices.' },
  { capability: 'advanced_insights', title: 'Advanced training insights', detail: 'Deeper trends without locking your local history.' },
]

function durationLabel(period) {
  const match = /^P(?:(\d+)Y)?(?:(\d+)M)?(?:(\d+)W)?(?:(\d+)D)?$/.exec(period || '')
  if (!match) return period || ''
  const years = Number(match[1] || 0)
  const months = Number(match[2] || 0)
  const weeks = Number(match[3] || 0)
  const days = Number(match[4] || 0)
  if (years === 1 && !months && !weeks && !days) return t('year')
  if (months === 1 && !years && !weeks && !days) return t('month')
  const totalDays = weeks * 7 + days
  if (totalDays) return t('{0} days', totalDays)
  return period
}

function entitlementStatus(entitlement) {
  if (!entitlement) return null
  if (entitlement.stale) return 'Subscription verification is temporarily out of date. Service features may wait for a connection.'
  if (entitlement.state === 'active') return 'KUVVET Pro is active.'
  if (entitlement.state === 'grace') return 'Payment needs attention. Pro remains active during the grace period.'
  if (entitlement.state === 'cancelled' && entitlement.entitled) return 'Cancelled — Pro remains active until the paid period ends.'
  if (entitlement.state === 'pending') return 'Purchase is pending in Google Play.'
  if (entitlement.state === 'hold') return 'Pro is on hold. Update your payment method in Google Play.'
  if (entitlement.state === 'expired') return 'Pro has expired. Your local training data is unchanged.'
  if (entitlement.state === 'revoked') return 'This purchase was revoked. Your local training data is unchanged.'
  return 'Free plan is active.'
}

export default function Pro() {
  const nav = useNavigate()
  const toast = useUI(s => s.toast)
  const setRuntimeEntitlement = useUI(s => s.setEntitlement)
  const user = useStore(s => s.user)
  const [plans, setPlans] = useState([])
  const [entitlement, setEntitlement] = useState(null)
  const [selected, setSelected] = useState('P1Y')
  const [available, setAvailable] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    let live = true
    let purchaseListener = null
    ;(async () => {
      if (user) {
        try {
          const current = await refreshEntitlement()
          if (live) { setEntitlement(current); setRuntimeEntitlement(current) }
        } catch { /* Offline or verifier unavailable: never invent Pro access. */ }
      }
      const init = await initializeBilling()
      if (!live || !init.available) return
      const result = await listPlans()
      if (live) { setPlans(result.plans || []); setAvailable(true) }
      purchaseListener = await onPurchaseUpdated(async update => {
        if (update.responseCode === 'USER_CANCELLED') return
        if (update.responseCode !== 'OK') return toast(t('Purchase verification failed. Please try Restore purchases.'))
        try {
          const verified = await verifyPurchases(update.purchases || [])
          if (live) { setEntitlement(verified); setRuntimeEntitlement(verified) }
          toast(verified?.entitled ? t('KUVVET Pro is active.') : t('Purchase is not active yet.'))
        } catch (error) {
          toast(error.message || t('Purchase verification failed. Please try Restore purchases.'))
        }
      })
    })().catch(() => {})
    return () => { live = false; purchaseListener?.remove() }
  }, [setRuntimeEntitlement, toast, user])

  const capabilitySet = useMemo(() => new Set([
    ...(entitlement?.availableCapabilities || []),
    ...(entitlement?.capabilities || []),
  ]), [entitlement])
  const hasLiveBenefit = BENEFITS.some(benefit => capabilitySet.has(benefit.capability))
  const storePlan = plans.find(plan => plan.billingPeriod === selected)
  const checkoutReady = !!(user && available && storePlan && hasLiveBenefit && !entitlement?.entitled)

  const buy = async () => {
    if (!user) return toast(t('Connect this app to your account before subscribing.'))
    if (!hasLiveBenefit) return toast(t('This service is not available yet. Checkout is paused.'))
    if (!available || !storePlan) return toast(t('Google Play checkout is available in the Android app.'))
    setBusy(true)
    try {
      const { obfuscatedAccountId } = await billingAccountReference()
      await purchasePlan({ ...storePlan, obfuscatedAccountId })
      toast(t('Complete your purchase in Google Play.'))
    }
    catch (error) { if (error.code !== 'USER_CANCELLED') toast(error.message || t('Purchase could not start.')) }
    finally { setBusy(false) }
  }

  const restore = async () => {
    if (!user) return toast(t('Connect this app to your account before restoring purchases.'))
    setBusy(true)
    try {
      const result = await restorePurchases()
      const verified = await verifyPurchases(result.purchases || [])
      setEntitlement(verified)
      setRuntimeEntitlement(verified)
      toast(verified?.entitled ? t('KUVVET Pro is active.') : t('No active purchase was found.'))
    }
    catch (error) { toast(error.message || t('Restore failed.')) }
    finally { setBusy(false) }
  }

  return <main className="pro-page narrow">
    <header className="pro-head">
      <button className="iconbtn" onClick={() => nav('/settings')} aria-label={t('Settings')}><Icon name="chevronLeft" /></button>
      <BrandMark />
      <span className="pro-badge">PRO</span>
    </header>
    <div className="kuvvet-kicker">{t('Membership')}</div>
    <h1>{t('More service. Your training stays yours.')}</h1>
    <p className="pro-lead">{t('Local workout logging, plans, history and export remain free. Pro funds optional service-backed features.')}</p>
    {entitlement && <p className={`pro-status ${entitlement.entitled ? 'active' : ''}`}>
      {t(entitlementStatus(entitlement))}
    </p>}

    <section className="pro-compare" aria-label={t('Free forever')}>
      <div className="pro-compare-head"><span>{t('Free forever')}</span><strong>{t('Included')}</strong></div>
      <p><Icon name="checkCircle" />{t('Local workout logging, plans, history, basic stats, import and export')}</p>
    </section>

    <section className="pro-benefits" aria-label={t('Included with Pro')}>
      <h2>{t('Included with Pro')}</h2>
      <ul className="pro-features">
        {BENEFITS.map(benefit => {
          const active = capabilitySet.has(benefit.capability)
          return <li key={benefit.capability} className={active ? '' : 'unavailable'}>
            <Icon name={active ? 'checkCircle' : 'clock'} />
            <span><strong>{t(benefit.title)}</strong>{t(benefit.detail)}</span>
            <em data-benefit-state={active ? 'available' : 'unavailable'}>{t(active ? 'Available now' : 'Coming soon')}</em>
          </li>
        })}
      </ul>
    </section>

    <div className="pro-plans">
      {Object.entries(PERIODS).map(([period, meta]) => {
        const plan = plans.find(candidate => candidate.billingPeriod === period)
        return <button key={period} className={selected === period ? 'on' : ''} onClick={() => setSelected(period)}>
          <span>{t(meta.label)}{period === 'P1Y' && <em>{t('Best value')}</em>}</span>
          <strong>{plan?.formattedPrice || '—'}<small>/{t(meta.unit)}</small></strong>
        </button>
      })}
    </div>

    {storePlan?.trialPeriod && <p className="pro-offer-term">{t('Trial: {0}', durationLabel(storePlan.trialPeriod))}</p>}
    {storePlan && <p className="pro-offer-term">{t('Renews every {0} at {1}', durationLabel(storePlan.billingPeriod), storePlan.formattedPrice)}</p>}
    <button data-pro-checkout className="kuvvet-primary" onClick={buy} disabled={busy || !checkoutReady}>
      <span>{t(storePlan?.trialPeriod ? 'Start free trial' : 'Subscribe with Google Play')}</span><Icon name="arrowRight" />
    </button>
    {!hasLiveBenefit && <p className="pro-note pro-warning">{t('This service is not available yet. Checkout is paused.')}</p>}
    {hasLiveBenefit && !storePlan && <p className="pro-note">{t('Google Play checkout is available in the Android app.')}</p>}
    {storePlan && <p className="pro-note">{t('Google Play shows the final localized price before confirmation.')}</p>}
    <button className="kuvvet-text-action" onClick={restore} disabled={busy}>{t('Restore purchases')}</button>
    {entitlement?.entitled && <button className="kuvvet-text-action" onClick={() => manageSubscription()}>{t('Manage subscription')}</button>}
    <p className="pro-legal">
      {t('Cancel anytime in Google Play. Losing Pro never deletes or hides local workout data.')}{' '}
      <a href="https://barisariburnu.com.tr/projects/kuvvet-app/terms/" target="_blank" rel="noopener">{t('Terms')}</a>{' · '}
      <a href="https://barisariburnu.com.tr/projects/kuvvet-app/privacy/" target="_blank" rel="noopener">{t('Privacy')}</a>{' · '}
      <a href="https://barisariburnu.com.tr/projects/kuvvet-app/billing-help/" target="_blank" rel="noopener">{t('Billing help')}</a>
    </p>
  </main>
}
