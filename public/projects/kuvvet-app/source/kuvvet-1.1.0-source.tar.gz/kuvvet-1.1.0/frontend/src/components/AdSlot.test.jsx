// @vitest-environment happy-dom
import React, { act } from 'react'
import { createRoot } from 'react-dom/client'
import { MemoryRouter, useNavigate } from 'react-router-dom'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import AdSlot from './AdSlot.jsx'
import { useUI } from '../store/useUI.js'

const mocks = vi.hoisted(() => ({
  initialize: vi.fn(),
  show: vi.fn(),
  hide: vi.fn(),
}))

vi.mock('../lib/ads.js', async importOriginal => {
  const actual = await importOriginal()
  return {
    ...actual,
    adsAvailable: () => true,
    initializeAds: (...args) => mocks.initialize(...args),
    showBanner: (...args) => mocks.show(...args),
    hideBanner: (...args) => mocks.hide(...args),
    subscribeAdsRuntime: () => () => {},
  }
})

globalThis.IS_REACT_ACT_ENVIRONMENT = true
let root
let container
let nav

function Driver() {
  nav = useNavigate()
  return React.createElement(AdSlot)
}

async function renderAt(path) {
  container = document.createElement('div')
  document.body.appendChild(container)
  root = createRoot(container)
  await act(async () => {
    root.render(React.createElement(MemoryRouter, { initialEntries: [path] }, React.createElement(Driver)))
    await Promise.resolve()
    await Promise.resolve()
  })
}

beforeEach(() => {
  mocks.initialize.mockReset().mockResolvedValue({
    initialized: true, available: true, configured: true, canRequestAds: true,
    privacyOptionsRequired: false, mode: 'test'
  })
  mocks.show.mockReset().mockResolvedValue({ visible: true })
  mocks.hide.mockReset().mockResolvedValue({ visible: false })
  useUI.getState().resetMonetization()
  useUI.getState().setEntitlement({ tier: 'free', entitled: false })
})

afterEach(() => {
  if (root) act(() => root.unmount())
  container?.remove()
  root = null
  container = null
})

describe('route-aware banner lifecycle', () => {
  it('shows one banner on an approved free surface after initialization', async () => {
    await renderAt('/library')
    expect(mocks.show).toHaveBeenCalledTimes(1)
    expect(mocks.show).toHaveBeenCalledWith('library')
  })

  it('hides before a protected route and never shows there', async () => {
    await renderAt('/stats')
    mocks.hide.mockClear()
    mocks.show.mockClear()
    await act(async () => { nav('/workout'); await Promise.resolve() })
    expect(mocks.hide).toHaveBeenCalled()
    expect(mocks.show).not.toHaveBeenCalled()
  })

  it('never shows for verified Pro', async () => {
    useUI.getState().setEntitlement({ tier: 'pro', entitled: true })
    await renderAt('/plan')
    expect(mocks.show).not.toHaveBeenCalled()
    expect(mocks.hide).toHaveBeenCalled()
  })
})
