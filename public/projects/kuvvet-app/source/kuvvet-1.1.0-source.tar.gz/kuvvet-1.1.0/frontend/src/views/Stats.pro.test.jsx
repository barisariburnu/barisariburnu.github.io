import React, { act } from 'react'
import { createRoot } from 'react-dom/client'
import { Window } from 'happy-dom'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import Stats from './Stats.jsx'

const NOW = Date.UTC(2026, 7, 31, 12)
const mocks = vi.hoisted(() => ({
  entitlement: { tier: 'free', state: 'free', entitled: false, capabilities: [] },
  S: {
    unit: 'kg', body: 'male', effort: 'none', targetW: null, bodyweight: [], routines: [],
    workouts: [{
      id: 'w1', d: '2026-08-20', start: Date.UTC(2026, 7, 20, 12),
      entries: [{ id: '1001', sets: [{ done: true, w: 80, r: 8 }] }],
    }],
  },
}))

vi.mock('../store/useStore.js', () => ({ useStore: selector => selector({ S: mocks.S }) }))
vi.mock('../store/useUI.js', () => ({ useUI: selector => selector({ entitlement: mocks.entitlement }) }))
vi.mock('react-router-dom', () => ({ useNavigate: () => vi.fn() }))
vi.mock('../sheets.jsx', () => ({
  bwSheet: vi.fn(), goalSheet: vi.fn(), calendarSheet: vi.fn(), workoutDetailSheet: vi.fn(),
  WorkoutRow: () => React.createElement('div'), bwDeltaColor: () => 'inherit',
}))
vi.mock('../components/LineChart.jsx', () => ({ default: () => React.createElement('div') }))
vi.mock('../components/Heatmap.jsx', () => ({ default: () => React.createElement('div') }))
vi.mock('../components/BodyMap.jsx', () => ({
  default: () => React.createElement('div'), BodyMapLegend: () => React.createElement('div'),
}))
vi.mock('../components/Icon.jsx', () => ({ default: props => React.createElement('span', props) }))

let dom
let root
let container

async function renderStats() {
  dom = new Window({ url: 'http://localhost/' })
  globalThis.window = dom
  globalThis.document = dom.document
  Object.defineProperty(globalThis, 'navigator', { configurable: true, value: dom.navigator })
  globalThis.IS_REACT_ACT_ENVIRONMENT = true
  container = document.createElement('div')
  document.body.append(container)
  root = createRoot(container)
  await act(async () => root.render(React.createElement(Stats)))
}

beforeEach(() => {
  vi.spyOn(Date, 'now').mockReturnValue(NOW)
  mocks.entitlement = { tier: 'free', state: 'free', entitled: false, capabilities: [] }
})

afterEach(async () => {
  if (root) await act(async () => root.unmount())
  root = null
  container = null
  dom?.close()
  dom = null
  vi.restoreAllMocks()
})

describe('Stats advanced insights access', () => {
  it('keeps free basic statistics visible and renders only a truthful locked preview', async () => {
    await renderStats()
    expect(container.textContent).toContain('Workouts')
    expect(container.textContent).toContain('Exercise progress')
    expect(container.querySelector('[data-pro-insights="locked"]')).toBeTruthy()
    expect(container.querySelector('[data-pro-insights="ready"]')).toBeFalsy()
    expect(container.textContent).not.toContain('1 completed workouts')
  })

  it('renders local insight results only with verified advanced-insights capability', async () => {
    mocks.entitlement = {
      tier: 'pro', state: 'active', entitled: true, capabilities: ['advanced_insights'],
      lastVerifiedAt: new Date(NOW).toISOString(), staleAfter: new Date(NOW + 86400000).toISOString(),
    }
    await renderStats()
    expect(container.querySelector('[data-pro-insights="ready"]')).toBeTruthy()
    expect(container.querySelector('[data-pro-insights="locked"]')).toBeFalsy()
    expect(container.textContent).toContain('Volume')
    expect(container.textContent).toContain('90-day window')
  })
})
