import { useNavigate } from 'react-router-dom'
import { useStore } from '../store/useStore.js'
import { effectiveRoutine, streakWeeks, lastBW, setsDoneActive } from '../lib/history.js'
import { fmtNum, fmtDate, todayISO, weekKey } from '../lib/format.js'
import { t } from '../lib/i18n.js'
import { bwSheet, goalSheet, startFlow, loadStarterPlan } from '../sheets.jsx'
import LineChart from '../components/LineChart.jsx'
import Icon from '../components/Icon.jsx'
import BrandMark from '../components/BrandMark.jsx'
import { effortSummary } from '../lib/effort.js'

// KUVVET home: one decision first, two quiet supporting regions below it.
export default function Home() {
  const nav = useNavigate()
  const S = useStore(s => s.S)
  const routine = effectiveRoutine(S, todayISO())
  const doneToday = S.workouts.filter(w => w.d === todayISO()).at(-1) || null
  const active = S.active
  const bw = lastBW(S)
  const totalSets = active
    ? active.entries.reduce((n, e) => n + (e.sets?.length || 0), 0)
    : routine?.ex.reduce((n, e) => n + (Number(e.sets) || 0), 0) || 0
  const doneSets = setsDoneActive(active)
  const completed = !active && !!doneToday
  const sessionName = active?.name || doneToday?.name || routine?.name || t('Rest day')
  const exerciseCount = active?.entries?.length || routine?.ex?.length || doneToday?.entries?.length || 0
  const wThisWeek = S.workouts.filter(w => weekKey(w.d) === weekKey(todayISO())).length
  const effort = effortSummary(S, 28)
  const bwPoints = S.bodyweight.slice(-30).map(b => ({ t: b.t || new Date(b.d).getTime(), y: b.w, d: b.d }))

  const primaryLabel = active ? t('Resume workout')
    : routine ? (completed ? t('Train again') : t('Start workout'))
      : t('Build a plan')

  const onPrimary = () => {
    if (active) return nav('/workout')
    if (routine) return startFlow(routine.id)
    nav('/plan')
  }

  return (
    <main className="kuvvet-home narrow">
      <header className="kuvvet-head">
        <BrandMark />
        <button className="kuvvet-settings" onClick={() => nav('/settings')} aria-label={t('Settings')}>
          <Icon name="gear" />
        </button>
      </header>

      <section className="kuvvet-hero" aria-labelledby="today-workout">
        <div className="kuvvet-kicker">{t("Today's workout")}</div>
        <h1 id="today-workout">{sessionName}</h1>
        <p>
          {routine || active || completed
            ? t('{0} exercises · {1} working sets', exerciseCount, totalSets || t('completed'))
            : t('A quiet day. Build a plan when you are ready.')}
        </p>

        {(active || completed) && totalSets > 0 && (
          <div className="kuvvet-progress" aria-label={t('{0} of {1} sets complete', active ? doneSets : totalSets, totalSets)}>
            <div className="kuvvet-progress-copy">
              <span>{completed ? t('Workout complete') : t('Set progress')}</span>
              <strong>{active ? doneSets : totalSets}<small>/{totalSets}</small></strong>
            </div>
            <div className="kuvvet-progress-track"><i style={{ width: `${Math.min(100, (active ? doneSets : totalSets) / totalSets * 100)}%` }} /></div>
          </div>
        )}

        <button className="kuvvet-primary" onClick={onPrimary}>
          <span>{primaryLabel}</span><Icon name={active ? 'play' : routine ? 'arrowRight' : 'calendar'} />
        </button>

        {!S.routines.length && !active && (
          <button className="kuvvet-text-action" onClick={loadStarterPlan}>{t('Or load the starter plan')}</button>
        )}
      </section>

      <section className="kuvvet-panel kuvvet-weight" aria-labelledby="body-weight-title">
        <div className="kuvvet-section-head">
          <div>
            <div className="kuvvet-kicker" id="body-weight-title">{t('Body weight')}</div>
            {bw ? <div className="kuvvet-weight-value">{fmtNum(bw.w)} <small>{S.unit}</small></div> : <div className="kuvvet-weight-value empty-value">—</div>}
          </div>
          <div className="kuvvet-mini-actions">
            <button onClick={goalSheet} aria-label={t('Set weight goal')}><Icon name="target" /></button>
            <button onClick={() => bwSheet()} aria-label={t('Log body weight')}><Icon name="plus" /></button>
          </div>
        </div>
        {bw ? <>
          <div className="kuvvet-weight-date">{t('Last check-in')} · {fmtDate(bw.d, true)}</div>
          <div className="chart kuvvet-chart"><LineChart points={bwPoints} h={104} unit={S.unit} axes={false} goal={S.targetW} /></div>
        </> : <p className="kuvvet-empty-copy">{t('Log your first weight to start the curve.')}</p>}
      </section>

      <section className="kuvvet-summary" aria-labelledby="weekly-summary-title">
        <div className="kuvvet-kicker" id="weekly-summary-title">{t('Weekly summary')}</div>
        <div className="kuvvet-metrics">
          <button onClick={() => nav('/stats')}><strong>{wThisWeek}</strong><span>{t('This week')}</span></button>
          <button onClick={() => nav('/history')}><strong>{S.workouts.length}</strong><span>{t('Total workouts')}</span></button>
          <button onClick={() => nav('/stats')}><strong>{effort.avg == null ? '—' : fmtNum(effort.avg)}</strong><span>{effort.avg == null ? t('Week streak') : t('Avg. effort (RIR)')}</span><em>{effort.avg == null ? streakWeeks(S) : ''}</em></button>
        </div>
      </section>
    </main>
  )
}
