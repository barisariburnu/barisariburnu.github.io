export default function BrandMark({ compact = false, className = '' }) {
  return (
    <div className={`brand-mark${compact ? ' compact' : ''} ${className}`.trim()} aria-label="KUVVET">
      <img src="/brand/kuvvet-mark.png" alt="" aria-hidden="true" />
      {!compact && <span>KUVVET</span>}
    </div>
  )
}
