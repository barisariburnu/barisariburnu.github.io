// @vitest-environment happy-dom
import React, { act } from 'react'
import { createRoot } from 'react-dom/client'
import { beforeEach, afterEach, describe, expect, it, vi } from 'vitest'
import Pro from './Pro.jsx'

const mocks = vi.hoisted(() => ({
  entitlement: { tier: 'free', state: 'free', entitled: false, capabilities: [], availableCapabilities: [] },
  plans: [],
  billingAvailable: true,
  purchase: vi.fn(),
  toast: vi.fn(),
}))

vi.mock('react-router-dom', () => ({ useNavigate: () => vi.fn() }))
vi.mock('../store/useStore.js', () => ({ useStore: selector => selector({ user: { id: 'u1' } }) }))
vi.mock('../store/useUI.js', () => ({ useUI: selector => selector({ toast: mocks.toast, setEntitlement: vi.fn() }) }))
vi.mock('../components/Icon.jsx', () => ({ default: () => React.createElement('span') }))
vi.mock('../components/BrandMark.jsx', () => ({ default: () => React.createElement('span', null, 'KUVVET') }))
vi.mock('../lib/billing.js', () => ({
  billingAccountReference: vi.fn(async () => ({ obfuscatedAccountId: 'account-ref' })),
  initializeBilling: vi.fn(async () => ({ available: mocks.billingAvailable })),
  listPlans: vi.fn(async () => ({ available: mocks.billingAvailable, plans: mocks.plans })),
  manageSubscription: vi.fn(),
  onPurchaseUpdated: vi.fn(async () => ({ remove() {} })),
  purchasePlan: (...args) => mocks.purchase(...args),
  refreshEntitlement: vi.fn(async () => mocks.entitlement),
  restorePurchases: vi.fn(async () => ({ purchases: [] })),
  verifyPurchases: vi.fn(async () => mocks.entitlement),
}))

globalThis.IS_REACT_ACT_ENVIRONMENT = true
let root
let container

async function renderPro() {
  container = document.createElement('div')
  document.body.appendChild(container)
  root = createRoot(container)
  await act(async () => { root.render(React.createElement(Pro)); await Promise.resolve(); await Promise.resolve() })
}

beforeEach(() => {
  mocks.entitlement = { tier: 'free', state: 'free', entitled: false, capabilities: [], availableCapabilities: [] }
  mocks.plans = []
  mocks.billingAvailable = true
  mocks.purchase.mockReset()
  mocks.toast.mockReset()
})

afterEach(() => {
  if (root) act(() => root.unmount())
  container?.remove()
  root = null
  container = null
})

describe('truthful Pro offer', () => {
  it('keeps checkout paused and marks server benefits unavailable when no capability is live', async () => {
    mocks.plans = [{ productId: 'kuvvet_pro', offerToken: 'annual', formattedPrice: '$14.99', billingPeriod: 'P1Y' }]
    await renderPro()
    expect(container.textContent).toContain('Local workout logging, plans, history, basic stats, import and export')
    expect(container.textContent).toContain('Coming soon')
    expect(container.textContent).toContain('This service is not available yet. Checkout is paused.')
    expect(container.querySelector('[data-pro-checkout]').disabled).toBe(true)
  })

  it('uses Google Play trial and renewal terms when a service capability is available', async () => {
    mocks.entitlement = {
      tier: 'free', state: 'free', entitled: false, capabilities: [],
      availableCapabilities: ['cloud_backup', 'cloud_sync']
    }
    mocks.plans = [{
      productId: 'kuvvet_pro', offerToken: 'annual', formattedPrice: '₺99,99',
      billingPeriod: 'P1Y', trialPeriod: 'P1W'
    }]
    await renderPro()
    expect(container.textContent).toContain('Trial: 7 days')
    expect(container.textContent).toContain('Renews every year at ₺99,99')
    expect(container.querySelector('[data-pro-checkout]').disabled).toBe(false)
  })

  it('labels only entitlement-backed benefits as available for an active member', async () => {
    mocks.entitlement = {
      tier: 'pro', state: 'active', entitled: true,
      capabilities: ['ad_free', 'advanced_insights'], availableCapabilities: ['ad_free', 'advanced_insights']
    }
    await renderPro()
    const available = [...container.querySelectorAll('[data-benefit-state="available"]')]
    expect(available.map(node => node.closest('li').textContent)).toEqual(expect.arrayContaining([
      expect.stringContaining('No ads on any screen'),
      expect.stringContaining('Advanced training insights'),
    ]))
    expect(container.textContent).toContain('KUVVET Pro is active.')
  })
})
