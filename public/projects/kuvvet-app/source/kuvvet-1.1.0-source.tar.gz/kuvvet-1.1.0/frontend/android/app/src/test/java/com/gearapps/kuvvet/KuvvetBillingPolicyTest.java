package com.gearapps.kuvvet;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class KuvvetBillingPolicyTest {
    @Test
    public void queriesPurchasesAtEveryAuthoritativeBoundary() {
        assertTrue(KuvvetBillingPolicy.shouldQueryPurchases("connection"));
        assertTrue(KuvvetBillingPolicy.shouldQueryPurchases("foreground"));
        assertTrue(KuvvetBillingPolicy.shouldQueryPurchases("restore"));
        assertFalse(KuvvetBillingPolicy.shouldQueryPurchases("background"));
        assertFalse(KuvvetBillingPolicy.shouldQueryPurchases("checkout-started"));
    }

    @Test
    public void onlyPurchasedAndPendingStatesReachServerVerification() {
        assertTrue(KuvvetBillingPolicy.shouldEmitPurchaseState("PURCHASED"));
        assertTrue(KuvvetBillingPolicy.shouldEmitPurchaseState("PENDING"));
        assertFalse(KuvvetBillingPolicy.shouldEmitPurchaseState("UNSPECIFIED"));
    }
}
