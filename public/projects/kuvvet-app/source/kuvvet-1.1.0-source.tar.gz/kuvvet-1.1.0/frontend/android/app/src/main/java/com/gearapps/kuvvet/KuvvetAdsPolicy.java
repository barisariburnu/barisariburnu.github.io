package com.gearapps.kuvvet;

import java.util.Set;

final class KuvvetAdsPolicy {
    private static final Set<String> APPROVED_SURFACES = Set.of("library", "plan", "stats");

    private KuvvetAdsPolicy() {}

    static boolean isApprovedSurface(String surface) {
        return surface != null && APPROVED_SURFACES.contains(surface);
    }

    static boolean configurationReady(boolean debug, String mode, String appId, String bannerId) {
        if (debug) return "test".equals(mode);
        return "production".equals(mode)
            && appId != null && appId.matches("ca-app-pub-\\d+~\\d+")
            && bannerId != null && bannerId.matches("ca-app-pub-\\d+/\\d+");
    }
}
