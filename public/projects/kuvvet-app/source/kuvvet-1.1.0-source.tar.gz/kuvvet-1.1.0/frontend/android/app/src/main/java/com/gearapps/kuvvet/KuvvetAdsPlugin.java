package com.gearapps.kuvvet;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.ump.ConsentDebugSettings;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.FormError;
import com.google.android.ump.UserMessagingPlatform;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Consent-first, banner-only advertising bridge. React decides whether the route/tier is eligible;
 * this native boundary repeats the surface check and owns the single banner as defense in depth.
 */
@CapacitorPlugin(name = "KuvvetAds")
public class KuvvetAdsPlugin extends Plugin {
    private ConsentInformation consentInformation;
    private boolean mobileAdsInitialized;
    private FrameLayout bannerContainer;
    private AdView bannerView;
    private int originalWebViewBottomMargin = Integer.MIN_VALUE;

    @Override
    public void load() {
        consentInformation = UserMessagingPlatform.getConsentInformation(getContext());
    }

    @PluginMethod
    public void initialize(PluginCall call) {
        Activity activity = getActivity();
        if (activity == null) {
            call.resolve(state(false, false, "ACTIVITY_UNAVAILABLE"));
            return;
        }
        activity.runOnUiThread(() -> {
            ConsentRequestParameters.Builder parameters = new ConsentRequestParameters.Builder();
            if (BuildConfig.DEBUG) {
                parameters.setConsentDebugSettings(
                    new ConsentDebugSettings.Builder(getContext())
                        .setDebugGeography(ConsentDebugSettings.DebugGeography.DEBUG_GEOGRAPHY_EEA)
                        .build()
                );
            }
            consentInformation.requestConsentInfoUpdate(
                activity,
                parameters.build(),
                () -> UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                    activity,
                    formError -> finishInitialization(call, formError)
                ),
                requestError -> call.resolve(state(false, false, "CONSENT_REFRESH_FAILED"))
            );
        });
    }

    private void finishInitialization(PluginCall call, FormError formError) {
        boolean configured = configurationReady();
        boolean canRequest = configured && consentInformation.canRequestAds();
        if (!canRequest) {
            hideNativeBanner();
            call.resolve(state(configured, false, formError == null ? "CONSENT_REQUIRED" : "CONSENT_FORM_FAILED"));
            return;
        }
        if (mobileAdsInitialized) {
            call.resolve(state(true, true, "READY"));
            return;
        }
        MobileAds.initialize(getContext(), status -> {
            mobileAdsInitialized = true;
            call.resolve(state(true, true, "READY"));
        });
    }

    @PluginMethod
    public void showBanner(PluginCall call) {
        String surface = call.getString("surface", "");
        if (!KuvvetAdsPolicy.isApprovedSurface(surface)) {
            call.resolve(visibility(false, "SURFACE_BLOCKED", 0));
            return;
        }
        if (!configurationReady()) {
            call.resolve(visibility(false, "NOT_CONFIGURED", 0));
            return;
        }
        if (!mobileAdsInitialized || consentInformation == null || !consentInformation.canRequestAds()) {
            call.resolve(visibility(false, "CONSENT_REQUIRED", 0));
            return;
        }
        Activity activity = getActivity();
        if (activity == null) {
            call.resolve(visibility(false, "ACTIVITY_UNAVAILABLE", 0));
            return;
        }
        activity.runOnUiThread(() -> showNativeBanner(call));
    }

    private void showNativeBanner(PluginCall call) {
        if (bannerContainer != null && bannerContainer.getParent() != null && bannerView != null) {
            call.resolve(visibility(true, "VISIBLE", bannerView.getAdSize().getHeight()));
            return;
        }

        Activity activity = getActivity();
        int widthPixels = Math.max(1, activity.getResources().getDisplayMetrics().widthPixels);
        float density = activity.getResources().getDisplayMetrics().density;
        int widthDp = Math.max(1, Math.round(widthPixels / density));
        AdSize adSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(getContext(), widthDp);
        int heightPixels = Math.max(1, Math.round(adSize.getHeight() * density));

        bannerView = new AdView(getContext());
        bannerView.setAdUnitId(BuildConfig.KUVVET_BANNER_AD_UNIT_ID);
        bannerView.setAdSize(adSize);
        bannerContainer = new FrameLayout(getContext());
        bannerContainer.setBackgroundColor(Color.TRANSPARENT);
        bannerContainer.addView(bannerView, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        ));
        FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            heightPixels,
            Gravity.BOTTOM
        );
        ViewGroup content = activity.findViewById(android.R.id.content);
        content.addView(bannerContainer, containerParams);
        setWebViewBottomInset(heightPixels);

        AtomicBoolean completed = new AtomicBoolean(false);
        bannerView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                if (completed.compareAndSet(false, true)) {
                    call.resolve(visibility(true, "VISIBLE", adSize.getHeight()));
                }
            }

            @Override
            public void onAdFailedToLoad(LoadAdError error) {
                hideNativeBanner();
                if (completed.compareAndSet(false, true)) {
                    call.resolve(visibility(false, "LOAD_FAILED", 0));
                }
            }
        });
        bannerView.loadAd(new AdRequest.Builder().build());
    }

    @PluginMethod
    public void hideBanner(PluginCall call) {
        Activity activity = getActivity();
        if (activity == null) {
            call.resolve(visibility(false, "HIDDEN", 0));
            return;
        }
        activity.runOnUiThread(() -> {
            hideNativeBanner();
            call.resolve(visibility(false, "HIDDEN", 0));
        });
    }

    @PluginMethod
    public void showPrivacyOptions(PluginCall call) {
        Activity activity = getActivity();
        if (activity == null || consentInformation == null) {
            call.resolve(state(configurationReady(), false, "ACTIVITY_UNAVAILABLE"));
            return;
        }
        activity.runOnUiThread(() -> UserMessagingPlatform.showPrivacyOptionsForm(activity, formError -> {
            boolean canRequest = configurationReady() && consentInformation.canRequestAds();
            if (!canRequest) hideNativeBanner();
            call.resolve(state(configurationReady(), canRequest, formError == null ? "UPDATED" : "PRIVACY_OPTIONS_FAILED"));
        }));
    }

    private boolean configurationReady() {
        return BuildConfig.KUVVET_ADS_CONFIGURED && KuvvetAdsPolicy.configurationReady(
            BuildConfig.DEBUG,
            BuildConfig.KUVVET_AD_MODE,
            BuildConfig.KUVVET_AD_MOB_APP_ID,
            BuildConfig.KUVVET_BANNER_AD_UNIT_ID
        );
    }

    private JSObject state(boolean configured, boolean canRequestAds, String reason) {
        boolean privacyRequired = consentInformation != null
            && consentInformation.getPrivacyOptionsRequirementStatus()
            == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;
        return new JSObject()
            .put("initialized", true)
            .put("available", true)
            .put("configured", configured)
            .put("canRequestAds", canRequestAds)
            .put("privacyOptionsRequired", privacyRequired)
            .put("mode", BuildConfig.DEBUG ? "test" : BuildConfig.KUVVET_AD_MODE)
            .put("reason", reason);
    }

    private JSObject visibility(boolean visible, String reason, int heightDp) {
        return new JSObject()
            .put("available", true)
            .put("visible", visible)
            .put("heightDp", heightDp)
            .put("reason", reason);
    }

    private void setWebViewBottomInset(int pixels) {
        if (getBridge() == null || getBridge().getWebView() == null) return;
        ViewGroup.LayoutParams raw = getBridge().getWebView().getLayoutParams();
        if (!(raw instanceof ViewGroup.MarginLayoutParams)) return;
        ViewGroup.MarginLayoutParams margins = (ViewGroup.MarginLayoutParams) raw;
        if (originalWebViewBottomMargin == Integer.MIN_VALUE) originalWebViewBottomMargin = margins.bottomMargin;
        margins.bottomMargin = originalWebViewBottomMargin + pixels;
        getBridge().getWebView().setLayoutParams(margins);
    }

    private void hideNativeBanner() {
        if (bannerView != null) {
            bannerView.destroy();
            bannerView = null;
        }
        if (bannerContainer != null) {
            ViewGroup parent = (ViewGroup) bannerContainer.getParent();
            if (parent != null) parent.removeView(bannerContainer);
            bannerContainer = null;
        }
        if (originalWebViewBottomMargin != Integer.MIN_VALUE && getBridge() != null && getBridge().getWebView() != null) {
            ViewGroup.LayoutParams raw = getBridge().getWebView().getLayoutParams();
            if (raw instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams margins = (ViewGroup.MarginLayoutParams) raw;
                margins.bottomMargin = originalWebViewBottomMargin;
                getBridge().getWebView().setLayoutParams(margins);
            }
        }
    }

    @Override
    protected void handleOnDestroy() {
        Activity activity = getActivity();
        if (activity != null) activity.runOnUiThread(this::hideNativeBanner);
    }
}
