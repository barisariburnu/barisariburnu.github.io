package com.gearapps.kuvvet;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class KuvvetAdsPolicyTest {
    @Test
    public void onlySecondarySurfacesAreApproved() {
        assertTrue(KuvvetAdsPolicy.isApprovedSurface("library"));
        assertTrue(KuvvetAdsPolicy.isApprovedSurface("plan"));
        assertTrue(KuvvetAdsPolicy.isApprovedSurface("stats"));
        assertFalse(KuvvetAdsPolicy.isApprovedSurface("home"));
        assertFalse(KuvvetAdsPolicy.isApprovedSurface("workout"));
        assertFalse(KuvvetAdsPolicy.isApprovedSurface("history"));
        assertFalse(KuvvetAdsPolicy.isApprovedSurface("settings"));
        assertFalse(KuvvetAdsPolicy.isApprovedSurface("pro"));
    }

    @Test
    public void debugBuildUsesOnlyGoogleTestConfiguration() {
        assertTrue(KuvvetAdsPolicy.configurationReady(true, "test", "", ""));
        assertFalse(KuvvetAdsPolicy.configurationReady(true, "production", "ca-app-pub-1~2", "ca-app-pub-1/2"));
    }

    @Test
    public void releaseBuildFailsClosedWithoutCompleteProductionIds() {
        assertFalse(KuvvetAdsPolicy.configurationReady(false, "test", "ca-app-pub-1~2", "ca-app-pub-1/2"));
        assertFalse(KuvvetAdsPolicy.configurationReady(false, "production", "", "ca-app-pub-1/2"));
        assertFalse(KuvvetAdsPolicy.configurationReady(false, "production", "ca-app-pub-1~2", ""));
        assertTrue(KuvvetAdsPolicy.configurationReady(false, "production", "ca-app-pub-1~2", "ca-app-pub-1/2"));
    }
}
