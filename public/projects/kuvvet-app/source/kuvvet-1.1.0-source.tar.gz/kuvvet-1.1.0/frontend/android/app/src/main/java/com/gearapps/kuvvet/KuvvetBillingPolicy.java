package com.gearapps.kuvvet;

import java.util.Set;

final class KuvvetBillingPolicy {
    private static final Set<String> QUERY_BOUNDARIES = Set.of("connection", "foreground", "restore");
    private static final Set<String> VERIFIABLE_STATES = Set.of("PURCHASED", "PENDING");

    private KuvvetBillingPolicy() {}

    static boolean shouldQueryPurchases(String source) {
        return source != null && QUERY_BOUNDARIES.contains(source);
    }

    static boolean shouldEmitPurchaseState(String state) {
        return state != null && VERIFIABLE_STATES.contains(state);
    }
}
