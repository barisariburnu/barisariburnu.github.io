package com.gearapps.kuvvet;

import android.content.Intent;
import android.net.Uri;
import androidx.annotation.NonNull;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Minimal Google Play Billing bridge. Purchase tokens are passed to the web layer only so the
 * trusted backend can verify them; this plugin never grants entitlement or acknowledges a purchase.
 */
@CapacitorPlugin(name = "KuvvetBilling")
public class KuvvetBillingPlugin extends Plugin implements PurchasesUpdatedListener {

    private BillingClient billingClient;
    private boolean connecting;
    private final List<ConnectedAction> connectionQueue = new CopyOnWriteArrayList<>();
    private final Map<String, ProductDetails> productByOfferToken = new HashMap<>();

    private interface ConnectedAction {
        void run();

        void reject(BillingResult result);
    }

    @Override
    public void load() {
        billingClient = BillingClient.newBuilder(getContext())
            .setListener(this)
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .enableAutoServiceReconnection()
            .build();
    }

    @PluginMethod
    public void initialize(PluginCall call) {
        withConnection(
            new ConnectedAction() {
                @Override
                public void run() {
                    call.resolve(new JSObject().put("available", true));
                    queryAndEmit("connection");
                }

                @Override
                public void reject(BillingResult result) {
                    rejectCall(call, result);
                }
            }
        );
    }

    @PluginMethod
    public void listPlans(PluginCall call) {
        JSArray requestedIds = call.getArray("productIds");
        if (requestedIds == null || requestedIds.length() == 0) {
            rejectCall(call, "DEVELOPER_ERROR", "At least one subscription product ID is required", false);
            return;
        }

        List<QueryProductDetailsParams.Product> products = new ArrayList<>();
        for (int index = 0; index < requestedIds.length(); index++) {
            String productId = requestedIds.optString(index, "").trim();
            if (!productId.isEmpty()) {
                products.add(
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(productId)
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
                );
            }
        }

        if (products.isEmpty()) {
            rejectCall(call, "DEVELOPER_ERROR", "At least one valid subscription product ID is required", false);
            return;
        }

        withConnection(
            new ConnectedAction() {
                @Override
                public void run() {
                    QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(products).build();
                    billingClient.queryProductDetailsAsync(params, (result, queryResult) -> {
                        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                            rejectCall(call, result);
                            return;
                        }

                        JSArray plans = new JSArray();
                        productByOfferToken.clear();
                        for (ProductDetails details : queryResult.getProductDetailsList()) {
                            List<ProductDetails.SubscriptionOfferDetails> offers = details.getSubscriptionOfferDetails();
                            if (offers == null) continue;
                            for (ProductDetails.SubscriptionOfferDetails offer : offers) {
                                ProductDetails.PricingPhases phases = offer.getPricingPhases();
                                List<ProductDetails.PricingPhase> phaseList = phases.getPricingPhaseList();
                                if (phaseList.isEmpty()) continue;

                                ProductDetails.PricingPhase recurring = phaseList.get(phaseList.size() - 1);
                                String trialPeriod = null;
                                for (ProductDetails.PricingPhase phase : phaseList) {
                                    if (phase.getPriceAmountMicros() == 0 && !phase.getBillingPeriod().isEmpty()) {
                                        trialPeriod = phase.getBillingPeriod();
                                        break;
                                    }
                                }

                                JSObject plan = new JSObject()
                                    .put("productId", details.getProductId())
                                    .put("basePlanId", offer.getBasePlanId())
                                    .put("offerToken", offer.getOfferToken())
                                    .put("formattedPrice", recurring.getFormattedPrice())
                                    .put("billingPeriod", recurring.getBillingPeriod());
                                if (offer.getOfferId() != null) plan.put("offerId", offer.getOfferId());
                                if (trialPeriod != null) plan.put("trialPeriod", trialPeriod);
                                plans.put(plan);
                                productByOfferToken.put(offer.getOfferToken(), details);
                            }
                        }
                        call.resolve(new JSObject().put("available", true).put("plans", plans));
                    });
                }

                @Override
                public void reject(BillingResult result) {
                    rejectCall(call, result);
                }
            }
        );
    }

    @PluginMethod
    public void purchase(PluginCall call) {
        String productId = call.getString("productId", "").trim();
        String offerToken = call.getString("offerToken", "").trim();
        ProductDetails details = productByOfferToken.get(offerToken);
        if (productId.isEmpty() || offerToken.isEmpty() || details == null || !productId.equals(details.getProductId())) {
            rejectCall(call, "NO_ELIGIBLE_OFFER", "Refresh plans and select an eligible Google Play offer", false);
            return;
        }

        withConnection(
            new ConnectedAction() {
                @Override
                public void run() {
                    BillingFlowParams.ProductDetailsParams productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(details)
                        .setOfferToken(offerToken)
                        .build();
                    BillingFlowParams.Builder flowBuilder = BillingFlowParams.newBuilder().setProductDetailsParamsList(List.of(productParams));
                    String accountId = call.getString("obfuscatedAccountId");
                    if (accountId != null && !accountId.isBlank()) flowBuilder.setObfuscatedAccountId(accountId);

                    BillingResult result = billingClient.launchBillingFlow(getActivity(), flowBuilder.build());
                    if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                        call.resolve(resultEnvelope(result));
                    } else {
                        rejectCall(call, result);
                    }
                }

                @Override
                public void reject(BillingResult result) {
                    rejectCall(call, result);
                }
            }
        );
    }

    @PluginMethod
    public void restore(PluginCall call) {
        withConnection(
            new ConnectedAction() {
                @Override
                public void run() {
                    QueryPurchasesParams params = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build();
                    billingClient.queryPurchasesAsync(params, (result, purchases) -> {
                        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                            rejectCall(call, result);
                            return;
                        }
                        call.resolve(new JSObject().put("available", true).put("purchases", purchasesEnvelope(purchases)));
                    });
                }

                @Override
                public void reject(BillingResult result) {
                    rejectCall(call, result);
                }
            }
        );
    }

    @PluginMethod
    public void queryPurchases(PluginCall call) {
        restore(call);
    }

    @PluginMethod
    public void manage(PluginCall call) {
        String productId = call.getString("productId", "").trim();
        StringBuilder url = new StringBuilder("https://play.google.com/store/account/subscriptions");
        if (!productId.isEmpty()) {
            url.append("?sku=").append(Uri.encode(productId));
            url.append("&package=").append(Uri.encode(getContext().getPackageName()));
        }
        try {
            getActivity().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url.toString())));
            call.resolve(new JSObject().put("available", true));
        } catch (RuntimeException error) {
            rejectCall(call, "UNAVAILABLE", "Google Play subscription management is unavailable", true);
        }
    }

    @Override
    public void onPurchasesUpdated(@NonNull BillingResult result, List<Purchase> purchases) {
        notifyListeners(
            "purchaseUpdated",
            resultEnvelope(result).put("purchases", purchasesEnvelope(purchases == null ? List.of() : purchases)),
            true
        );
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        queryAndEmit("foreground");
    }

    private void queryAndEmit(String source) {
        if (!KuvvetBillingPolicy.shouldQueryPurchases(source)) return;
        withConnection(new ConnectedAction() {
            @Override
            public void run() {
                QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                    .setProductType(BillingClient.ProductType.SUBS)
                    .build();
                billingClient.queryPurchasesAsync(params, (result, purchases) -> {
                    if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
                    notifyListeners(
                        "purchaseUpdated",
                        resultEnvelope(result)
                            .put("source", source)
                            .put("purchases", purchasesEnvelope(purchases)),
                        true
                    );
                });
            }

            @Override
            public void reject(BillingResult result) {
                // Foreground reconciliation is best-effort; the web layer still asks the server.
            }
        });
    }

    @Override
    protected void handleOnDestroy() {
        connectionQueue.clear();
        productByOfferToken.clear();
        if (billingClient != null) billingClient.endConnection();
    }

    private void withConnection(ConnectedAction action) {
        if (billingClient == null) load();
        if (billingClient.isReady()) {
            action.run();
            return;
        }

        connectionQueue.add(action);
        if (connecting) return;
        connecting = true;
        billingClient.startConnection(
            new BillingClientStateListener() {
                @Override
                public void onBillingSetupFinished(@NonNull BillingResult result) {
                    connecting = false;
                    List<ConnectedAction> queued = new ArrayList<>(connectionQueue);
                    connectionQueue.clear();
                    for (ConnectedAction queuedAction : queued) {
                        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) queuedAction.run();
                        else queuedAction.reject(result);
                    }
                }

                @Override
                public void onBillingServiceDisconnected() {
                    connecting = false;
                }
            }
        );
    }

    private JSObject resultEnvelope(BillingResult result) {
        return new JSObject()
            .put("responseCode", stableCode(result.getResponseCode()))
            .put("debugMessage", result.getDebugMessage());
    }

    private JSArray purchasesEnvelope(List<Purchase> purchases) {
        JSArray array = new JSArray();
        for (Purchase purchase : purchases) {
            String state = purchaseState(purchase.getPurchaseState());
            if (!KuvvetBillingPolicy.shouldEmitPurchaseState(state)) continue;
            array.put(
                new JSObject()
                    .put("productIds", new JSArray(purchase.getProducts()))
                    .put("purchaseToken", purchase.getPurchaseToken())
                    .put("purchaseTime", purchase.getPurchaseTime())
                    .put("state", state)
                    .put("acknowledged", purchase.isAcknowledged())
                    .put("autoRenewing", purchase.isAutoRenewing())
            );
        }
        return array;
    }

    private String purchaseState(int state) {
        if (state == Purchase.PurchaseState.PURCHASED) return "PURCHASED";
        if (state == Purchase.PurchaseState.PENDING) return "PENDING";
        return "UNSPECIFIED";
    }

    private void rejectCall(PluginCall call, BillingResult result) {
        String code = stableCode(result.getResponseCode());
        String message = result.getDebugMessage().isBlank() ? "Google Play Billing request failed" : result.getDebugMessage();
        rejectCall(call, code, message, retryable(result.getResponseCode()));
    }

    private void rejectCall(PluginCall call, String code, String message, boolean retryable) {
        call.reject(message, code, new JSObject().put("retryable", retryable));
    }

    private boolean retryable(int responseCode) {
        return responseCode == BillingClient.BillingResponseCode.SERVICE_DISCONNECTED ||
        responseCode == BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE ||
        responseCode == BillingClient.BillingResponseCode.ERROR ||
        responseCode == BillingClient.BillingResponseCode.NETWORK_ERROR;
    }

    private String stableCode(int responseCode) {
        return switch (responseCode) {
            case BillingClient.BillingResponseCode.OK -> "OK";
            case BillingClient.BillingResponseCode.USER_CANCELED -> "USER_CANCELLED";
            case BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> "ITEM_ALREADY_OWNED";
            case BillingClient.BillingResponseCode.DEVELOPER_ERROR -> "DEVELOPER_ERROR";
            case BillingClient.BillingResponseCode.SERVICE_DISCONNECTED -> "DISCONNECTED";
            case BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE,
                BillingClient.BillingResponseCode.ERROR,
                BillingClient.BillingResponseCode.NETWORK_ERROR -> "SERVICE_ERROR";
            case BillingClient.BillingResponseCode.BILLING_UNAVAILABLE -> "UNAVAILABLE";
            default -> "UNKNOWN";
        };
    }
}
