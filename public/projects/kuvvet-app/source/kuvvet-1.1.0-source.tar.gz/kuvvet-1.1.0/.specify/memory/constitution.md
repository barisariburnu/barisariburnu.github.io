<!--
Sync Impact Report
- Version change: template -> 1.0.0
- Added principles:
  - I. Open Source and License Integrity
  - II. Local-First Privacy
  - III. English-First LTR Internationalization
  - IV. Tested Domain Logic
  - V. Minimal, Accessible Mobile UX
- Added sections:
  - Product and Monetization Constraints
  - Delivery and Quality Gates
- Removed sections: none
- Follow-up TODOs: none
-->
# KUVVET Constitution

## Core Principles

### I. Open Source and License Integrity
All distributed modified application code MUST remain available under AGPL-3.0-or-later with
prominent source-access and attribution notices. Proprietary value MAY exist in operated services,
support, signing, hosting, and convenience, but the application MUST NOT hide AGPL-covered source
or misrepresent upstream ownership. Third-party exercise media MUST retain its own notices and
licensing terms. This protects user freedom and keeps commercialization legally and ethically
aligned with the upstream project.

### II. Local-First Privacy
Core workout planning, logging, history, body-weight tracking, backup export, and restore MUST work
without an account, network connection, telemetry, or subscription. User data MUST stay on-device
unless the user explicitly enables a remote service. Any paid synchronization or backup service
MUST state what leaves the device, encrypt data in transit, provide deletion/export controls, and
degrade safely to the local experience when unavailable.

### III. English-First LTR Internationalization
English MUST be the source language, runtime default, store-listing primary language, and fallback
for missing translations. Supported translations MUST be limited to left-to-right scripts for this
product phase. Turkish and the existing principal LTR languages MUST remain selectable without
forking business logic or persisted data. New user-facing copy MUST use translation keys and MUST
remain usable when translated text expands by at least 30%. RTL locales and bidirectional layout
support are explicitly out of scope until this constitution is amended.

### IV. Tested Domain Logic
Anything that decides training progression, interprets a completed workout, calculates entitlements,
or changes persisted data MUST live in deterministic helpers with colocated automated tests.
Purchase state MUST be verified by a trusted backend before durable Pro access is granted. Tests
MUST cover active, cancelled-with-access, grace-period, on-hold, expired, restored, and pending
subscription states. Visual click-through testing alone is never sufficient for domain or billing
logic.

### V. Minimal, Accessible Mobile UX
Every primary screen MUST present one dominant user goal, no more than two supporting regions, and
touch targets of at least 48 CSS pixels. Visual hierarchy MUST rely on spacing, alignment,
typography, and restrained color before cards, borders, or elevation. The selected graphite,
off-white, and acid-lime KUVVET system is the baseline visual language. Critical actions and text
MUST meet WCAG 2.2 AA contrast, respect reduced motion, remain reachable with one hand, and avoid
obstructing Android system insets.

## Product and Monetization Constraints

- The Android product MUST use Google Play Billing for in-app digital subscriptions where required.
- Pricing MUST be localized by the store. Initial targets are USD 1.99 monthly / USD 14.99 yearly
  and TRY 14.99 monthly / TRY 99.99 yearly, with a seven-day trial subject to Play Console support.
- The free tier MUST retain complete private local logging. Pro MAY unlock managed encrypted cloud
  backup, cross-device synchronization, and service-backed advanced analytics.
- Subscription UI MUST show localized price, billing period, trial terms, renewal behavior,
  cancellation route, privacy policy, terms, and purchase restoration before purchase.
- The app MUST be branded KUVVET. Android package identity MUST use an organization-owned reverse
  domain chosen before Play Store production signing; temporary development identifiers MUST never
  be published.
- Dependencies MUST remain minimal. A new runtime dependency requires a documented security,
  maintenance, bundle-size, and architectural justification.

## Delivery and Quality Gates

1. Every feature begins with a Spec Kit specification containing independently testable user
   stories and measurable, technology-agnostic success criteria.
2. Planning MUST document AGPL impact, privacy/data flow, localization scope, offline behavior,
   billing trust boundaries, and rollback or degradation behavior.
3. Implementation MUST preserve existing public data formats or provide migration and backward
   compatibility tests.
4. Before handoff, frontend tests, production web/mobile build, relevant Android checks, and a
   browser-rendered design comparison against the selected mock MUST pass.
5. Release readiness MUST include Play Console product IDs, signed-bundle handling, source-offer
   location, privacy policy, data-safety declaration, store copy, screenshots, and license notices.

## Governance

This constitution supersedes informal project conventions where they conflict. Amendments require a
documented rationale, a semantic version change, and a migration note for any affected specification
or implementation. MAJOR versions remove or redefine a principle, MINOR versions add a principle or
materially expand obligations, and PATCH versions clarify wording without changing obligations.
Every plan and review MUST include a constitution check; any exception MUST be explicit, time-bound,
and recorded in the relevant plan. `CLAUDE.md`, `CONTRIBUTING.md`, upstream AGPL terms, and the active
Spec Kit artifacts provide operational guidance but cannot weaken these rules.

**Version**: 1.0.0 | **Ratified**: 2026-08-26 | **Last Amended**: 2026-08-26
