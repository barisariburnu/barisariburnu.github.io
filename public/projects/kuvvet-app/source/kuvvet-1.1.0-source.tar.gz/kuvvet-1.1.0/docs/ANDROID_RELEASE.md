# KUVVET Android Release Checklist

KUVVET is a branded Android distribution derived from openGym. Its permanent Android identity is
`com.gearapps.kuvvet` and its publisher website is `https://barisariburnu.com.tr`. The current
release candidate is signed and passes the local build gates. Publishing remains blocked only by
the external inputs listed below.

## Release blockers

- Publish the 1.1 corresponding-source archive and the updated advertising/cloud legal text under
  `https://barisariburnu.com.tr/projects/kuvvet-app/` before submitting versionCode 3.
- Archive the commercial media purchase receipt and supplied EULA, then confirm they cover the
  exact openGym media revision already imported into the private release workspace. A Pages
  deployment artifact serves matching thumbnails/animations from the publisher domain without
  committing them to the public source repository; the mobile build makes no request to the
  upstream mirror.
- Deploy a trusted HTTPS billing verifier, configure its Google Play service-account credential and
  create the `kuvvet_pro` subscription/base plans in Play Console.

## Signing status

- The local upload key was generated outside the repository and the release AAB was signed with it.
- `credentials.json` follows `credentials.example.json`, is ignored by Git and Docker, and has local
  owner-only permissions. It must never be committed or copied into the source archive.
- Enroll the upload certificate in Play App Signing during the first artifact upload and keep the
  recovery material outside GitHub.
- Current release candidate: `kuvvet-1.1.0.aab` (`versionCode 3`, `versionName 1.1.0`).
- AAB SHA-256: `34d5ef94efd34b71bc00a4403e9e9851c5bae9759ebd831b2d7368400ffd4c9c`.
- AAB size: 9,287,993 bytes; exercise media is served from the publisher domain rather than bundled.
- Upload signing certificate SHA-256: `83:A6:4E:37:B6:89:C1:34:88:5D:D8:07:41:8B:45:24:CA:99:2F:AE:CC:68:1C:B8:1E:C0:2F:F3:BA:87:D9:9C`.
- Signature verification: `jar verified`; release lint reports 0 errors and 35 non-blocking
  generated/icon warnings. Google Mobile Ads 25.4.0 emits Kotlin-metadata compatibility diagnostics
  during lint under the current Android toolchain, but compilation, lint, signing, and bundle tasks
  complete successfully.
- Local release archive: `/Users/baris/.kuvvet-release/kuvvet-1.1.0.aab`, owner-readable only.
- Rollback artifact retained: `kuvvet-1.0.1.aab`, SHA-256
  `aa09592d85405b5d4dd2ff61d03b20dc6447d8c6649bb8d45204e71f000fa60b`.

## Product and billing inputs

| Item | Launch target |
|---|---|
| Product ID | `kuvvet_pro` |
| Android application ID | `com.gearapps.kuvvet` |
| Publisher website | `https://barisariburnu.com.tr` |
| Base plans | `monthly` (`P1M`), `annual` (`P1Y`) |
| Trial | 7 days for eligible new subscribers |
| US target | $1.99/month, $14.99/year |
| Turkey target | ₺14.99/month, ₺99.99/year |
| Free tier | All local workout logging, plans, history, import and export |
| Pro scope | Optional managed backup/sync and service-backed advanced analytics |

Google Play's store-returned `formattedPrice` is authoritative in the checkout UI. Pricing targets
must be rechecked in the Play Console before each release; taxes, store rounding and exchange-rate
changes can alter localized tiers.

### Production verifier operations

- Run the API only behind HTTPS with persistent, encrypted-at-rest storage mounted at `DATA_DIR`;
  ephemeral container storage is not acceptable for accounts, entitlement records or the session
  signing secret.
- Supply the Google Play credential through `GOOGLE_PLAY_SERVICE_ACCOUNT_FILE` as a read-only
  secret mount. Do not place JSON credentials in an environment file, image layer, log or backup.
- Supply a separately generated 32-byte base64 key as `BILLING_TOKEN_ENCRYPTION_KEY`; the
  `credentials.json` field is the local source of this deployment secret, not a file consumed by
  the API automatically. Rotate it only with a migration of existing encrypted token records.
- Set `KUVVET_PRO_CAPABILITIES` to a comma-separated allowlist only for benefits actually deployed,
  such as `ad_free,cloud_backup,cloud_sync,advanced_insights`. An empty value keeps checkout
  paused and prevents unavailable services from being advertised.
- Grant the service account only the Play Console permissions required to view subscriptions,
  manage orders and acknowledge purchases for KUVVET. Keep project-wide owner/editor roles off.
- Verify `/api/health` returns HTTP 200 and `/api/config` reports `billing_available: true` before
  enabling the Play product. The container health check covers only process health; production
  monitoring must also alert on verifier authorization failures and failed backup jobs.
- Rotate the service-account key at least annually and immediately after suspected exposure: add a
  new key, update the secret mount, restart and verify the service, then revoke the old key. Retain
  no more than one active replacement key beyond the short overlap window.
- Back up `DATA_DIR` daily, encrypt backups, test a restore before launch, and keep at least one
  copy outside the runtime host. Raw purchase tokens never enter logs or API responses; the server
  persists an ownership hash plus authenticated encrypted token material for lifecycle refresh.

## AdMob and app-ads.txt readiness

- The publisher's HTTPS file was verified at
  `https://barisariburnu.com.tr/app-ads.txt` on 2026-08-26.
- Verified public record: `google.com, pub-8939295877328751, DIRECT, f08c47fec0942fa0`.
- Set `https://barisariburnu.com.tr` as the developer website in the Play listing so AdMob can find
  the root-level file.
- Approved policy: the free tier may use only low-distraction adaptive banners on Library, Plan,
  and Stats. Home, active Workout, History, Settings, and Pro are ad-free; a verified Pro tier is
  ad-free everywhere. Interstitial, rewarded, and app-open ads are not part of the release plan.
- The public publisher ID is not an AdMob Android app ID. Before adding the Mobile Ads SDK, obtain
  the app ID shaped `ca-app-pub-...~...`, the required ad-unit IDs shaped `ca-app-pub-.../...`, and
  create the Privacy & Messaging configuration in AdMob.
- Do not commit Play Console or AdMob login email addresses, credentials, recovery codes,
  `google-services.json`, signing keys, or service-account keys to this repository.
- Integrate UMP before any ad request, expose privacy options when required, update Data safety and
  Privacy Policy disclosures, and use Google's dedicated test IDs/test devices before release.

### Local 1.1 advertising and billing configuration

Copy `credentials.example.json` to the ignored `credentials.json` and keep it owner-readable only.
The `android.ads.mode` value must be `test` during development; the sample IDs in the example are
Google's public Android test identifiers and must never be replaced by live IDs in committed files.
Production IDs are local secrets even though they are embedded into the signed Android manifest at
build time. `android.billing.serviceAccountFile` points to a read-only backend secret and is never
packaged in the application. `android.billing.tokenEncryptionKey` protects refreshable purchase
references at rest and must be generated independently from the upload-key passwords.

For a production build, require all four checks before permitting an ad request: native Android,
approved Library/Plan/Stats surface, current UMP permission, and valid production app/banner IDs.
Missing or malformed configuration disables advertising without reserving blank layout space.

## KUVVET 1.1 release gates

- Privacy: update the hosted policy with advertising consent, device/ad identifiers, Google Mobile
  Ads processing, managed-cloud opt-in, export, and deletion behavior before rollout.
- Play declarations: the signed 1.1 bundle contains Mobile Ads, so re-answer Ads, Advertising ID,
  Data safety, and reviewer-access forms from that bundle. The 1.0.1 no-ads declaration is not valid
  for 1.1.
- Subscription: use license testers to validate store-localized price/trial text, backend
  verification and acknowledgement, restore, grace, cancellation, hold, expiry, and revoke.
- Rollback: retain the approved 1.0.1 AAB and release record. Because Play cannot reuse a version
  code, recovery ships a new, higher code; server-side ads and Pro services remain independently
  disableable while local training continues.

### Play declaration baseline for versionCode 3

This matrix is the release-team input, not a substitute for reviewing the exact questions shown by
Play Console. Recheck it against the signed dependency report and live backend immediately before
submission.

| Declaration | 1.1 answer / evidence |
|---|---|
| Contains ads | **Yes** — free-tier adaptive banner only on Library, Plan, and Stats |
| Advertising ID | **Used** by Google Mobile Ads when the selected serving mode permits it; ads/analytics/fraud prevention |
| Ads consent | UMP refreshes at launch; unresolved/denied consent results in no KUVVET ad request; privacy-options entry appears when required |
| Data safety — identifiers | Google Mobile Ads may collect/share device or account identifiers, including Ad ID; encrypted in transit |
| Data safety — app activity | Google Mobile Ads may collect/share app interactions for advertising/measurement |
| Data safety — diagnostics | Google Mobile Ads may collect/share diagnostic data for SDK performance and fraud prevention |
| Data safety — purchase | Purchase token is sent to the publisher verifier over HTTPS, stored with authenticated encryption plus an ownership hash, and never logged or returned |
| Data safety — fitness | Local by default; plans, workouts, body weight, and settings leave the device only after managed-cloud opt-in or explicit self-hosted connection |
| Account deletion | In-app deletion plus `projects/kuvvet-app/account-deletion/`; managed-cloud export/deletion remains separately reachable |
| Subscription | Store-localized price/period/trial, auto-renewal, cancellation, restore, Terms, Privacy, and billing help disclosed before checkout |

Google's current Mobile Ads disclosure says the SDK automatically processes IP address, product
interactions, diagnostics, and device/account identifiers, while Ad ID collection can be disabled
or limited by configuration/serving mode. Review the official
[Google Mobile Ads data disclosure](https://developers.google.com/admob/android/privacy/play-data-disclosure)
and [UMP setup/privacy-options guidance](https://developers.google.com/admob/android/privacy)
again at submission time because SDK behavior and Play questions can change.

## Play Console checklist

- Create the app using `com.gearapps.kuvvet`; verify the value before the first uploaded artifact
  because the Play application ID cannot be changed afterward.
- Complete Data safety from actual runtime behavior: local workout data is not purchase data;
  purchase tokens go only to the trusted verifier and are excluded from logs, backups and analytics.
- Upload phone screenshots captured from the English source locale, plus localized LTR screenshots
  where listing copy is localized. Do not declare or upload RTL locales.
- Configure internal testing before closed/open tracks. Add license testers and validate purchase,
  pending, restore, cancellation, grace, hold, expiry and revoke transitions.
- Verify acknowledgement and backend entitlement verification before moving beyond internal testing.
- Confirm the listing states that subscriptions fund optional services and that local workout data
  remains accessible after cancellation.
- Link Source, Privacy Policy, Terms and billing help from both the Play listing and in-app Settings;
  their canonical prefix is `https://barisariburnu.com.tr/projects/kuvvet-app/`.
- Attach the exact release tag/commit, reproducible build steps, AAB checksum and source-offer URL to
  the release record.

## Build gates

Run the checks in `specs/001-kuvvet-android-subscriptions/quickstart.md`. A release candidate needs:

- frontend and API tests passing;
- production web and mobile builds passing;
- Android Lint and unit tests passing;
- equal-viewport visual QA for the selected KUVVET reference;
- accessibility review for 48px touch targets, English fallback, supported LTR locales and reduced
  motion;
- no unresolved user-facing `openGym` branding other than compatibility/migration and upstream
  attribution disclosures.
