import test from 'node:test';
import assert from 'node:assert/strict';
import { SyncError, createSyncRepository } from './sync.js';

const pro = { entitled: true, stale: false, capabilities: ['cloud_sync'] };
const state = note => ({ workouts: [{ id: 'w1', note }], routines: [] });

test('requires fresh Pro cloud capability and explicit consent for writes', () => {
  const repo = createSyncRepository();
  assert.throws(() => repo.put('u1', { baseRevision: null, state: state('a') }, pro), error => error.code === 'CLOUD_CONSENT_REQUIRED');
  assert.throws(() => repo.put('u1', { baseRevision: null, state: state('a'), consentAccepted: true }, { ...pro, stale: true }), error => error.code === 'PRO_REQUIRED');
});

test('creates revisions and rejects stale writers with the current envelope', () => {
  const repo = createSyncRepository({ now: () => Date.parse('2026-08-31T10:00:00Z') });
  const first = repo.put('u1', { baseRevision: null, deviceId: 'phone', state: state('a'), consentAccepted: true }, pro);
  assert.equal(first.revision, '1');
  const second = repo.put('u1', { baseRevision: '1', deviceId: 'tablet', state: state('b') }, pro);
  assert.equal(second.revision, '2');
  assert.throws(
    () => repo.put('u1', { baseRevision: '1', deviceId: 'phone', state: state('c') }, pro),
    error => error instanceof SyncError && error.code === 'SYNC_CONFLICT' && error.current.revision === '2',
  );
});

test('keeps export and remote deletion available after Pro expiry', () => {
  const repo = createSyncRepository();
  repo.put('u1', { baseRevision: null, state: state('a'), consentAccepted: true }, pro);
  assert.deepEqual(repo.exportState('u1'), state('a'));
  assert.equal(repo.delete('u1'), true);
  assert.equal(repo.get('u1'), null);
});
