import crypto from 'node:crypto';

export class SyncError extends Error {
  constructor(code, message, { status = 400, current = null } = {}) {
    super(message);
    this.code = code;
    this.status = status;
    this.current = current;
  }
}

const clone = value => value == null ? value : JSON.parse(JSON.stringify(value));
const hash = value => crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');

export function requireCloudAccess(entitlement) {
  if (!entitlement?.entitled || entitlement.stale || !entitlement.capabilities?.includes('cloud_sync')) {
    throw new SyncError('PRO_REQUIRED', 'Fresh KUVVET Pro cloud access is required', { status: 403 });
  }
}

export function createSyncRepository({ envelopes = {}, consents = {}, now = Date.now } = {}) {
  return {
    envelopes,
    consents,
    get(accountRef) { return clone(envelopes[accountRef] || null); },
    put(accountRef, request = {}, entitlement) {
      requireCloudAccess(entitlement);
      if (!consents[accountRef]) {
        if (request.consentAccepted !== true) {
          throw new SyncError('CLOUD_CONSENT_REQUIRED', 'Explicit cloud consent is required', { status: 403 });
        }
        consents[accountRef] = {
          enabled: true,
          acceptedDisclosureVersion: String(request.disclosureVersion || '1'),
          acceptedAt: new Date(now()).toISOString(),
          dataCategories: ['training_state'],
        };
      }
      const current = envelopes[accountRef] || null;
      const baseRevision = request.baseRevision == null ? null : String(request.baseRevision);
      if ((current?.revision || null) !== baseRevision) {
        throw new SyncError('SYNC_CONFLICT', 'Remote training data changed', { status: 409, current: clone(current) });
      }
      if (!request.state || typeof request.state !== 'object' || Array.isArray(request.state)) {
        throw new SyncError('SYNC_INVALID', 'Sync state must be an object');
      }
      const revision = String((Number(current?.revision) || 0) + 1);
      const envelope = {
        schemaVersion: 1,
        revision,
        updatedAt: new Date(now()).toISOString(),
        deviceId: String(request.deviceId || ''),
        state: clone(request.state),
        contentHash: hash(request.state),
      };
      envelopes[accountRef] = envelope;
      return clone(envelope);
    },
    exportState(accountRef) { return clone(envelopes[accountRef]?.state || null); },
    delete(accountRef) {
      const existed = !!envelopes[accountRef] || !!consents[accountRef];
      delete envelopes[accountRef];
      delete consents[accountRef];
      return existed;
    },
  };
}
