# Android Billing Bridge Contract

The bridge is available only in the native Android build. Web and unsupported devices return a
typed `UNAVAILABLE` result and keep the free local experience operational.

## `billing.initialize()`

Returns `{ available: boolean, reason?: string }`. Exactly one active store connection is reused
while the app is foregrounded. Disconnects trigger bounded reconnection and do not block app boot.

## `billing.listPlans({ productIds })`

Returns eligible store products:

```json
{
  "plans": [
    {
      "productId": "kuvvet_pro",
      "basePlanId": "monthly",
      "offerId": "trial-7d",
      "offerToken": "opaque-store-token",
      "formattedPrice": "$1.99",
      "billingPeriod": "P1M",
      "trialPeriod": "P7D"
    }
  ]
}
```

The UI MUST display `formattedPrice`; it MUST NOT synthesize localized prices.

## `billing.purchase({ productId, offerToken, obfuscatedAccountId })`

Launches the store-owned purchase sheet. The method resolves only the launch result. Final state is
delivered through `purchaseUpdated` and must still be verified by the backend.

## `billing.restore()`

Queries current subscription purchases and returns raw purchase envelopes for immediate trusted
verification. No client-only Pro state is granted.

## `billing.manage({ productId })`

Opens the store subscription-management route for KUVVET. If no product is known, it opens the
account subscription list.

## Event: `purchaseUpdated`

```json
{
  "responseCode": "OK",
  "purchases": [
    {
      "productIds": ["kuvvet_pro"],
      "purchaseToken": "opaque-store-token",
      "purchaseTime": 1787731200000,
      "state": "PURCHASED",
      "acknowledged": false,
      "autoRenewing": true
    }
  ]
}
```

Supported states: `PURCHASED`, `PENDING`, `UNSPECIFIED`. Tokens are sensitive and MUST be sent only
to the configured trusted verifier over HTTPS, then removed from client memory when processing ends.

## Error contract

Every method rejects with `{ code, message, retryable }`. Stable codes: `UNAVAILABLE`,
`DISCONNECTED`, `NO_ELIGIBLE_OFFER`, `USER_CANCELLED`, `ITEM_ALREADY_OWNED`, `SERVICE_ERROR`,
`DEVELOPER_ERROR`, and `UNKNOWN`. User cancellation is not presented as an application error.
