# Implementation Plan: KUVVET Android Rebrand and Subscriptions

**Branch**: `001-kuvvet-android-subscriptions` | **Date**: 2026-08-26 |
**Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/001-kuvvet-android-subscriptions/spec.md`

## Summary

Rebrand the existing openGym React/Capacitor application as KUVVET, faithfully implement the
selected graphite and acid-lime Android home screen, preserve English as the default and fallback
for the existing 12 LTR translation packs, and introduce a freemium Pro subscription architecture.
The first implementation slice delivers the brand system, simplified home experience, Android
display identity, LTR enforcement, reliable exercise media, legal/release scaffolding, and testable
entitlement and advertising-policy domains.
Native checkout and trusted server verification follow through explicit bridge and HTTP contracts
without weakening offline local workout logging.

## Technical Context

**Language/Version**: JavaScript ES2022 on Node.js 22; React 19; Java 17-compatible Android source

**Primary Dependencies**: React Router, Zustand, Capacitor 7; Google Play Billing Library for the
Android-only purchase bridge; Google Mobile Ads and UMP only after production identifiers are
provided; no new frontend UI dependency

**Storage**: Existing `localStorage` plus Capacitor native-file mirror for workout state; plain JSON
files in the self-hosted API; verified billing records stored separately from workout state

**Testing**: Vitest for pure frontend/domain helpers; Node test runner for API helpers; JUnit for
native billing bridge; production Vite build; Android Gradle assemble/bundle checks; browser design QA

**Target Platform**: Android 6.0+ through the existing Capacitor shell; current evergreen browsers
remain supported for the self-hosted PWA

**Project Type**: Existing mobile application plus optional lightweight Node service

**Performance Goals**: Maintain 60 fps scrolling on supported phones; show the usable home screen
within 1.5 seconds after local state is available; start/resume workout in one tap; keep added brand
assets below 250 KB combined after optimization

**Constraints**: AGPL-3.0-or-later source offer; offline-first core; no app-owned telemetry; dependency-light;
English fallback; LTR-only locale catalog; store-localized prices; trusted backend verification;
permanent Android identity `com.gearapps.kuvvet`; publisher website `barisariburnu.com.tr`; ads only
on approved secondary free-tier surfaces after consent; Pro and active training are ad-free

**Scale/Scope**: One primary redesigned screen, global brand tokens, 13 LTR locale choices including
English, monthly and annual subscription offers, six principal entitlement lifecycle states, and
one Android distribution channel

## Constitution Check

*GATE: Passed before research and re-checked after design.*

| Principle / Gate | Plan Evidence | Result |
|------------------|---------------|--------|
| Open source and license integrity | Source offer and upstream attribution are release deliverables; paid value is service convenience | PASS |
| Local-first privacy | Core logging, import/export, history, and weight tracking remain offline and free | PASS |
| English-first LTR i18n | `en` remains default/fallback; existing LTR catalog is retained; Android RTL mirroring is disabled | PASS |
| Tested domain logic | Entitlement state is a pure tested helper; trusted verification is required before granting Pro | PASS |
| Minimal accessible mobile UX | Selected visual has one primary action, two supporting regions, 48px targets, AA palette, reduced-motion support | PASS |
| Product and monetization constraints | Store-localized monthly/yearly plans, seven-day offer, restore/manage paths, free local tier | PASS |
| Exercise media resilience | Demo/mobile use a commit-pinned snapshot; self-host stays local-first; failures render a safe fallback | PASS |
| Advertising restraint | Pure policy blocks training/core surfaces and all Pro ads; native requests require configuration and consent | PASS |
| Delivery and quality gates | Tests, production/mobile build, Android checks, and browser visual comparison are in quickstart/tasks | PASS |

Post-design re-check: the data model and contracts keep purchase tokens out of workout exports,
define explicit non-entitled states, and do not introduce an account gate for the free tier. No
constitution exception is required.

## Project Structure

### Documentation (this feature)

```text
specs/001-kuvvet-android-subscriptions/
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/
│   ├── billing-api.yaml
│   └── billing-bridge.md
└── tasks.md
```

### Source Code (repository root)

```text
frontend/
├── public/
│   ├── brand/
│   ├── icon-180.png
│   ├── icon-512.png
│   └── manifest.json
├── src/
│   ├── components/
│   │   ├── BrandMark.jsx
│   │   └── TabBar.jsx
│   ├── lib/
│   │   ├── entitlement.js
│   │   ├── entitlement.test.js
│   │   ├── backup.js
│   │   ├── monetization.js
│   │   ├── i18n-core.js
│   │   ├── billing.js
│   │   └── ads.js
│   ├── views/
│   │   ├── Home.jsx
│   │   ├── Pro.jsx
│   │   └── Settings.jsx
│   └── index.css
└── android/
    └── app/
        ├── build.gradle
        └── src/main/
            ├── AndroidManifest.xml
            ├── java/.../BillingPlugin.java
            └── res/

api/
├── server.js
├── billing.js
└── billing.test.js

assets/
└── brand/
    ├── kuvvet-mark.png
    └── selected-home-reference.png
```

**Structure Decision**: Extend the existing single React application and Capacitor Android shell.
Billing state is isolated in pure frontend/API helpers and one native bridge; workout-domain files
and persistence formats remain unchanged. The existing optional Node API is the trusted verification
boundary rather than a new service or framework.

## Complexity Tracking

No constitution violations require justification. The native billing bridge is necessary because
the product sells Android digital services; it is kept behind a small documented contract and adds
only Google's official billing runtime.
