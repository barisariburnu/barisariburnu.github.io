# Tasks: KUVVET Android Rebrand and Subscriptions

**Input**: Design documents from `/specs/001-kuvvet-android-subscriptions/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: Domain and billing tests are required by the constitution. Visual flows use browser QA.

**Organization**: Tasks are grouped by user story so each slice can be implemented and tested
independently.

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Install Spec Kit artifacts and establish versioned visual/release references.

- [x] T001 Store the selected mock and optimized KUVVET logo sources in assets/brand/
- [x] T002 Update PWA and Android display metadata in frontend/index.html, frontend/public/manifest.json, frontend/capacitor.config.json, and frontend/android/app/src/main/res/values/strings.xml
- [x] T003 [P] Apply the permanent Android ID `com.gearapps.kuvvet` and document publisher/release inputs in docs/ANDROID_RELEASE.md

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Shared brand, locale, entitlement, and visual foundations.

- [x] T004 Add KUVVET color/spacing/type tokens and responsive foundations in frontend/src/index.css
- [x] T005 [P] Create the reusable brand mark component in frontend/src/components/BrandMark.jsx
- [x] T006 [P] Lock the LTR language catalog and English fallback invariants in frontend/src/lib/i18n-core.js and frontend/src/lib/i18n-core.test.js
- [x] T007 [P] Add entitlement state tests before implementation in frontend/src/lib/entitlement.test.js
- [x] T008 Implement pure entitlement normalization and access rules in frontend/src/lib/entitlement.js

**Checkpoint**: Brand, locale, and access-state foundations are independently testable.

---

## Phase 3: User Story 1 - Start Today's Workout Quickly (Priority: P1) MVP

**Goal**: Recreate the selected graphite/lime home screen and make the primary start/resume flow work.

**Independent Test**: With seeded planned, active, rest-day, and empty states, the home screen exposes
the correct single primary action and enters the appropriate flow in one tap.

- [x] T009 [US1] Replace the card-heavy home hierarchy with the selected layout in frontend/src/views/Home.jsx
- [x] T010 [US1] Add scoped home-screen layout, states, and 320-600px responsiveness in frontend/src/index.css
- [x] T011 [US1] Simplify bottom navigation to the four selected destinations in frontend/src/components/TabBar.jsx
- [x] T012 [US1] Wire planned, active, rest-day, and empty-state primary actions in frontend/src/views/Home.jsx
- [x] T013 [US1] Validate start/resume/settings/navigation interactions in the in-app browser and record evidence in design-qa.md

**Checkpoint**: User Story 1 is a demonstrable MVP matching the selected visual target.

---

## Phase 4: User Story 2 - Use KUVVET in an LTR Language (Priority: P2)

**Goal**: Keep English primary while retaining every existing LTR translation and robust fallback.

**Independent Test**: A clean install starts in English; every listed locale can enter the primary
workout flow at 320px without a hidden control; invalid/unsupported locale input falls back to English.

- [x] T014 [P] [US2] Add English-first brand/home translation keys to frontend/src/locales/tr.js and verify fallback for other locale packs
- [x] T015 [US2] Set document direction to LTR and reject unsupported locales in frontend/src/App.jsx and frontend/src/lib/i18n-core.js
- [x] T016 [US2] Disable Android RTL mirroring in frontend/android/app/src/main/AndroidManifest.xml
- [x] T017 [US2] Run locale switching and narrow-width browser checks and append evidence to design-qa.md

**Checkpoint**: English-first and all supported LTR locales remain independently usable.

---

## Phase 5: User Story 3 - Subscribe to KUVVET Pro (Priority: P3)

**Goal**: Provide a secure, restorable monthly/annual Pro flow without gating local workout data.

**Independent Test**: Store test purchases map active/grace/cancelled-paid states to Pro and all
pending/hold/expired/revoked/unverified states to free, with restore and management paths available.

- [x] T018 [P] [US3] Implement the web-safe billing adapter contract in frontend/src/lib/billing.js
- [x] T019 [P] [US3] Add the official billing dependency and Capacitor bridge in frontend/android/app/build.gradle and frontend/android/app/src/main/java/
- [x] T020 [US3] Create the localized Pro plan, restore, status, and management screen in frontend/src/views/Pro.jsx
- [x] T021 [US3] Add the Pro route and Settings entry in frontend/src/App.jsx and frontend/src/views/Settings.jsx
- [x] T022 [P] [US3] Write API entitlement and verification tests in api/billing.test.js
- [x] T023 [US3] Implement store-verification normalization and redaction in api/billing.js
- [x] T024 [US3] Add authenticated billing verification and entitlement routes in api/server.js
- [ ] T025 [US3] Validate purchase, pending, restore, cancel, grace, hold, and expiry with Play license testers per specs/001-kuvvet-android-subscriptions/quickstart.md

**Checkpoint**: User Story 3 is production-code complete after external Play test evidence exists.

---

## Phase 6: User Story 4 - Verify a Trustworthy Open-Source Release (Priority: P4)

**Goal**: Make source, privacy, terms, upstream attribution, and data ownership clear before release.

**Independent Test**: A reviewer can reach every disclosure, export local data offline, and verify
that store/service copy matches actual data flow.

- [x] T026 [P] [US4] Add KUVVET/upstream/source/privacy/terms/media disclosures to frontend/src/views/Settings.jsx and NOTICE.md
- [x] T027 [P] [US4] Create the Play listing, Data safety, pricing, source-offer, and signing checklist in docs/ANDROID_RELEASE.md
- [x] T028 [US4] Validate offline log/export/import without account or subscription gates using specs/001-kuvvet-android-subscriptions/quickstart.md

**Checkpoint**: Release transparency can be audited independently of purchase implementation.

---

## Phase 7: Polish & Cross-Cutting Concerns

- [x] T029 Run frontend, API, and Android automated tests from specs/001-kuvvet-android-subscriptions/quickstart.md
- [x] T030 Build production web and mobile artifacts and verify no unresolved primary display branding
- [x] T031 Capture an equal-viewport implementation image, compare it jointly with assets/brand/selected-home-reference.png, fix all P0-P2 findings, and set design-qa.md final result
- [x] T032 Review AGPL source offer, dependency impact, accessibility, reduced motion, and 48px touch targets against .specify/memory/constitution.md

---

## Phase 8: Exercise Media and Restrained Advertising

- [x] T033 Add publisher-hosted, rights-cleared per-exercise thumbnail/animation resolution and fallback tests in frontend/src/components/Media.jsx and frontend/src/components/Media.test.jsx
- [x] T034 Add image/GIF retry and localized non-broken fallbacks in frontend/src/components/Media.jsx and frontend/src/locales/tr.js
- [x] T035 Verify representative library thumbnails and an exercise GIF with non-zero dimensions in the local demo
- [x] T036 [P] Encode the approved free/Pro advertising rules in frontend/src/lib/monetization.js and frontend/src/lib/monetization.test.js
- [x] T037 [P] Add a web-safe native advertising bridge contract in frontend/src/lib/ads.js
- [ ] T038 Add the official Google Mobile Ads and UMP dependencies plus `KuvvetAds` Android bridge after the production AdMob app ID and ad-unit IDs are supplied
- [ ] T039 Render consent-gated adaptive banners only on Library, Plan, and Stats and verify that Home, Workout, History, Settings, and every Pro state stay ad-free
- [ ] T040 Complete AdMob/UMP test-device, consent withdrawal, Data safety, and Play internal-track verification

---

## Dependencies & Execution Order

- Phase 1 has no dependency.
- Phase 2 depends on Phase 1 and blocks all user stories.
- User Story 1 and User Story 2 are the visual/international MVP and may progress together after Phase 2.
- User Story 3 depends only on entitlement and locale foundations, not on the home redesign.
- User Story 4 may progress alongside User Story 3 after the public brand identity exists.
- Phase 7 runs after the stories selected for a release checkpoint are complete.

### Parallel Opportunities

- T003, T005, T006, and T007 touch independent files.
- After Phase 2, the Home/TabBar work (US1), Turkish translation/RTL work (US2), native billing
  bridge (US3), and release docs (US4) can be developed independently.
- T018/T019 and T022 can proceed in parallel before the Pro UI and API route integrations.
- T026 and T027 are separate application/documentation changes.

## Parallel Example: User Story 3

```text
Task: T018 Implement frontend billing adapter in frontend/src/lib/billing.js
Task: T019 Implement Android bridge in frontend/android/app/src/main/java/
Task: T022 Write trusted-verification tests in api/billing.test.js
```

## Implementation Strategy

### MVP First

1. Complete Phases 1-2.
2. Complete User Story 1 and the English-first portion of User Story 2.
3. Run browser fidelity and interaction QA.
4. Deliver the working branded Android-capable app while billing integration proceeds behind its
   stable contracts.

### Incremental Delivery

1. Brand + minimal home + English/LTR support.
2. Testable entitlement domain + Pro presentation.
3. Native checkout + trusted verification.
4. Legal/store/signing readiness + Play internal testing.

## Format Validation

All implementation tasks use `- [ ] T###`, include `[P]` only for independent file work, include a
`[US#]` label in story phases, and name concrete file paths.

## Phase 9: Convergence

- [ ] T041 [US3] Provision the publisher-operated HTTPS KUVVET service, configure the Google Play service-account verifier, and document secret rotation and health checks per FR-014 and Constitution IV (missing)
- [ ] T042 [US3] Connect the Android Pro flow to the publisher-operated service without gating local free features, and provide a policy-compliant reviewer access path per FR-012 and US3 (contradicts)
- [ ] T043 [US3] Create and activate the `kuvvet_pro` monthly and annual base plans, localized launch prices, and seven-day trial in Google Play Console per FR-010 and FR-011 (missing)
- [ ] T044 Complete Play Console release preparation by uploading store media, selecting production countries, finishing accurate policy declarations, and supplying reviewer instructions per Delivery and Quality Gate 5 (missing)
- [ ] T045 Archive the purchased commercial media receipt and supplied EULA, then verify that they cover the exact pinned snapshot before production submission (PURCHASE ATTESTED; DOCUMENT DELIVERY PENDING)
- [x] T046 Download openGym's pinned media revision, validate all 1,324 catalogue ID mappings, and resolve the app only to publisher-controlled HTTPS paths
- [x] T047 Deploy the media-only Pages artifact with 1,324 validated JPG/GIF mappings, verify live MIME responses plus pause/resume behavior, and rerun the release-candidate media checks
