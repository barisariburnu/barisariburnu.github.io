# Data Model: KUVVET Android Rebrand and Subscriptions

## Existing Training State

The persisted workout state remains backward compatible. Its storage key, import markers, routine
and workout shapes, and mobile file mirror do not change during rebrand. Product-facing export
filenames may use KUVVET, but readers continue accepting legacy openGym files.

## Brand Profile

| Field | Type | Rules |
|-------|------|-------|
| `name` | string | Fixed to `KUVVET` for this release |
| `markAsset` | path | Transparent optimized square source plus launcher derivatives |
| `background` | color | Graphite `#080908` baseline |
| `foreground` | color | Off-white `#F7F7F2` baseline |
| `accent` | color | Acid lime `#B8FF16`; critical pairings must pass AA |
| `sourceOfferUrl` | URL | HTTPS, reachable, exact source for distributed version |
| `privacyUrl` | URL | HTTPS and accessible before release |
| `termsUrl` | URL | HTTPS and accessible before release |

## Locale Preference

| Field | Type | Rules |
|-------|------|-------|
| `code` | enum | `en`, `de`, `es`, `fr`, `it`, `pt`, `pt-BR`, `pl`, `tr`, `ru`, `zh`, `ko`, `hi` |
| `source` | enum | `default`, `user` |
| `fallback` | string | Always `en` |

State transitions: clean install -> `en/default`; language choice -> selected `code/user`; invalid or
missing pack -> retain selected preference and render English fallback.

## Subscription Offer

| Field | Type | Rules |
|-------|------|-------|
| `productId` | string | Stable Play Console subscription product identifier |
| `basePlanId` | string | Monthly or annual base plan |
| `offerId` | string/null | Introductory offer when eligible |
| `offerToken` | string | Ephemeral token returned by the store; never hardcoded |
| `formattedPrice` | string | Store-localized display value; authoritative UI value |
| `billingPeriod` | ISO-8601 period | `P1M` or `P1Y` for launch plans |
| `trialPeriod` | ISO-8601 period/null | Target `P7D`; only shown when eligible |
| `eligible` | boolean | False prevents checkout launch |

## Purchase Record

| Field | Type | Rules |
|-------|------|-------|
| `purchaseTokenHash` | string | Server-side stable hash; raw token excluded from logs/exports |
| `productId` | string | Must match configured subscription product |
| `basePlanId` | string/null | Normalized from store response when available |
| `state` | enum | `pending`, `purchased`, `cancelled`, `revoked` |
| `acknowledged` | boolean | Initial completed purchase must become true |
| `purchasedAt` | timestamp | Store time in UTC |
| `verifiedAt` | timestamp/null | Set only after trusted store lookup |
| `accountRef` | string | Non-sensitive app user/service identity; never workout profile data |

## Entitlement

| Field | Type | Rules |
|-------|------|-------|
| `tier` | enum | `free`, `pro` |
| `state` | enum | `free`, `active`, `grace`, `cancelled`, `hold`, `expired`, `pending`, `revoked`, `unknown` |
| `entitled` | boolean | True only for `active`, `grace`, or paid-through `cancelled` |
| `paidThrough` | timestamp/null | Required for time-bounded access |
| `willRenew` | boolean | Store-authoritative renewal intent |
| `lastVerifiedAt` | timestamp/null | UTC time of last trusted result |
| `capabilities` | string[] | Service-backed features only; local core is never listed |

### Entitlement transitions

```text
free -> pending -> active -> cancelled -> expired
                    |  |        |
                    |  |        +-> active (resubscribe)
                    |  +-> grace -> active | hold -> expired
                    +-> revoked
unknown -> active | grace | cancelled | hold | expired | revoked
```

Rules:

- `pending`, `hold`, `expired`, `revoked`, `unknown`, and `free` are not entitled.
- `cancelled` is entitled only while `paidThrough` is in the future.
- A cached entitlement may keep already-granted service access only within the server-defined
  freshness window; it cannot create access for a never-verified purchase.
- Losing Pro never deletes or hides local workout data.

## Legal Disclosure

| Field | Type | Rules |
|-------|------|-------|
| `kind` | enum | `source`, `license`, `privacy`, `terms`, `media`, `billing-help` |
| `titleKey` | string | English source/fallback translation key |
| `url` | URL/local route | Must be reachable or bundled |
| `version` | string/date | Identifies terms shown at purchase time |
| `requiredBeforePurchase` | boolean | True for privacy, terms, and billing help |

## Privacy Boundaries

- Workout data is not embedded in Purchase Record or Entitlement.
- Raw purchase tokens exist only in transit between the native bridge and trusted verification.
- Client logs, audit logs, backups, analytics, and support exports must redact raw purchase tokens.
- Pro cloud consent is separate from store purchase consent and explains workout-data transfer.
