# Quickstart: Validate KUVVET Android Rebrand and Subscriptions

## Prerequisites

- Node.js 22 and npm
- Java/Android SDK versions required by the checked-in Capacitor project
- A Google Play internal-test application and license tester for live subscription testing
- Permanent application ID `com.gearapps.kuvvet` (already applied); verify it matches the Play app
  before uploading the first artifact

## 1. Install and run frontend checks

```bash
cd frontend
npm ci
npm test
npm run build
```

Expected: all pure training and entitlement tests pass; the production build contains no unresolved
`openGym` display branding in primary app metadata or the home UI.

## 2. Preview the English-first mobile UI

```bash
cd frontend
npm run dev -- --host 0.0.0.0 --port 4173 --strictPort
```

Open the local preview in the Codex in-app browser at a 390 x 844 viewport. Seed demo data if needed.

Validate:

1. KUVVET mark and wordmark appear on graphite.
2. Today's workout is the single dominant region.
3. Start/resume navigates into the working workout flow.
4. Weight and weekly summary are the only supporting home regions.
5. Settings opens from the compact gear action.
6. Bottom navigation remains reachable and uses English labels.
7. Browser console has no errors.

## 3. Validate locales

For each code in `LANGS`, select it in Settings and repeat the home-to-workout action at 320 px and
390 px widths. Confirm English fallback for intentionally untranslated KUVVET copy and confirm the
selector has no RTL languages. Return to English and reload; English remains selected.

## 4. Build the mobile bundle and synchronize Android

```bash
cd frontend
npm run build:mobile
cd android
./gradlew test assembleDebug
```

Expected: Capacitor synchronization and Android debug build succeed. The launcher label is KUVVET,
RTL mirroring is disabled, and the visible icon uses the approved lime mark.

## 5. Validate entitlement domain states

Run the frontend and API unit tests and verify the matrix below:

| State | Expected service entitlement |
|-------|------------------------------|
| active | granted |
| grace | granted |
| cancelled before paid-through | granted |
| pending | denied |
| hold | denied |
| expired | denied |
| revoked | denied |
| unknown/unverified | denied |

No transition may delete or gate local workout data.

## 6. Google Play internal-test scenario

Configure `kuvvet_pro` with monthly and annual base plans and an eligible seven-day trial. Use the
store-returned localized prices. With license testers, verify purchase, pending completion/cancel,
restore, renewal, cancellation, grace, hold, and expiry. Compare responses with
[billing-api.yaml](./contracts/billing-api.yaml) and [billing-bridge.md](./contracts/billing-bridge.md).

## 7. Design QA and release checks

Capture the rendered home screen at the same content viewport as
`assets/brand/selected-home-reference.png`, create a combined comparison, and record results in the
repository-root `design-qa.md`. Fix every P0-P2 mismatch before handoff.

Before production signing, verify working privacy, terms, source-offer, upstream attribution, and
third-party media notice links and complete the Play Data safety declaration.
