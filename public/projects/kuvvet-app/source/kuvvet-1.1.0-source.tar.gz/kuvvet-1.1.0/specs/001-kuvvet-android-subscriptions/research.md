# Research: KUVVET Android Rebrand and Subscriptions

## Decision: Keep the existing React and Capacitor application

**Rationale**: The repository already produces a standalone Android application, preserves local
state through a native file mirror, and shares proven training logic with the PWA. Reusing it avoids
a risky rewrite and keeps imports, routines, and workout behavior compatible.

**Alternatives considered**: A native Kotlin rewrite would improve platform integration but would
duplicate the large workout domain and translation surface. A new cross-platform framework would
add runtime weight and migration work without improving the selected release goal.

## Decision: Use KUVVET with a graphite and acid-lime brand system

**Rationale**: The selected concept has the clearest one-action hierarchy and retains the original
product's dark gym-floor usability while removing nested cards. The geometric K is legible at
launcher size and does not depend on a culturally specific symbol.

**Alternatives considered**: The light editorial direction has excellent clarity but is less suited
to dim gym environments. The orange instrument direction is distinctive but visually denser and
less consistent with the requested minimal approach.

## Decision: English is the source, default, and fallback language

**Rationale**: The code already uses English source strings as translation keys and initializes new
profiles with `lang: 'en'`. Retaining this model avoids schema changes. The supported catalog stays
LTR-only: English, German, Spanish, French, Italian, Portuguese (Portugal/Brazil), Polish, Turkish,
Russian, Simplified Chinese, Korean, and Hindi.

**Alternatives considered**: Device-locale auto-selection was rejected for launch because it can
make first-run support and screenshots inconsistent. RTL support was rejected because it requires
a dedicated mirroring, typography, icon-direction, and QA program outside this feature.

## Decision: Preserve a useful free local tier

**Rationale**: Local-first logging is the product's strongest differentiator and remains compatible
with the upstream license and privacy promise. Pro monetizes managed encrypted cloud backup,
cross-device synchronization, and service-backed advanced analytics rather than holding local
workout data hostage.

**Alternatives considered**: A hard launch paywall would be simpler commercially but harms trial,
offline use, and trust. Feature-limiting routines or history was rejected because those capabilities
already exist locally and are central to user data ownership.

## Decision: Offer monthly and annual subscriptions with store-localized pricing

**Rationale**: Launch targets of USD 1.99 / USD 14.99 and TRY 14.99 / TRY 99.99 undercut the observed
Hevy and Strong reference prices while leaving an annual-value story. The displayed amount always
comes from the store because tax, eligibility, and currency tiers change by region. A seven-day trial
is configured as an eligible store offer rather than hardcoded in the app.

**Alternatives considered**: A lifetime purchase was deferred because managed services have ongoing
cost. A single annual plan reduces choice but performs poorly for users who want a low-commitment test.

## Decision: Use Google Play Billing with trusted backend verification

**Rationale**: Google's current integration guidance requires querying eligible product details,
handling purchase lifecycle callbacks, acknowledging completed purchases, and verifying purchases
before granting durable entitlements. The official Android billing library is the only new runtime
dependency; a small Capacitor plugin exposes product, purchase, restore, and management actions.

**Alternatives considered**: Client-only acknowledgement cannot securely grant service access.
Third-party subscription platforms reduce backend work but add vendor data flow, cost, and a large
dependency inconsistent with project constraints.

## Decision: Model entitlement separately from workout state

**Rationale**: Billing records have different sensitivity, lifecycle, and trust requirements from
user-owned training data. Separating them prevents purchase tokens from entering backup exports and
allows local features to remain stable when billing is unavailable.

**Alternatives considered**: Storing Pro status directly in the Zustand workout state is easy to
tamper with and would sync unverified access. Reusing the existing user subscription field without a
verification model would not represent pending, grace, hold, or revoked states safely.

## Decision: Use the publisher-selected permanent Android namespace

**Rationale**: The publisher supplied `com.gearapps.kuvvet` as the permanent Android application ID
and confirmed control of the publisher website `barisariburnu.com.tr`. The inherited upstream
namespace is therefore removed before any Play publication or signing setup.

**Alternatives considered**: Keeping the upstream author's namespace would misrepresent ownership
and complicate store signing. Deriving `tr.com.barisariburnu.kuvvet` from the website was not chosen
because the publisher explicitly selected the Gear Apps application identity.

## Decision: Maintain AGPL source transparency

**Rationale**: Selling the application or services is compatible with AGPL, but recipients of the
modified application and network users must receive the applicable source offer. KUVVET will retain
upstream authorship and media notices, and the release checklist treats a working source link as a
blocking artifact.

**Alternatives considered**: A closed-source fork conflicts with the repository license. Replacing
all upstream code solely to avoid the obligation is outside scope and would discard the mature domain.

## Primary References

- Google Play Billing integration: https://developer.android.com/google/play/billing/integrate
- Google Play backend integration: https://developer.android.com/google/play/billing/backend
- Google Play subscription lifecycle: https://developer.android.com/google/play/billing/subscriptions
- Google Play service fees: https://support.google.com/googleplay/android-developer/answer/11131145
- Hevy pricing: https://apps.apple.com/us/app/hevy-workout-tracker-gym-log/id1458862350
- Strong pricing: https://apps.apple.com/us/app/strong-workout-tracker-gym-log/id464254577
- GNU AGPL-3.0-or-later text: ../../LICENSE
