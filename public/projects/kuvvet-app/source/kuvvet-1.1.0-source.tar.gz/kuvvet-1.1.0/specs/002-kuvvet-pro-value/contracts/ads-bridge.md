# Contract: KUVVET Ads Native Bridge

## `initialize()`

Refreshes consent information, shows a required consent form, initializes Mobile Ads at most once,
and resolves with:

```json
{
  "available": true,
  "configured": true,
  "canRequestAds": true,
  "privacyOptionsRequired": false,
  "mode": "test"
}
```

Errors resolve to a deny-by-default state when possible. No caller may infer consent from a previous
launch without calling `initialize()`.

## `showBanner({ surface })`

Accepted surfaces: `library`, `plan`, `stats`. The native bridge rejects any other value. The caller
must already have an eligible result from the deterministic advertising decision helper.

Success:

```json
{ "available": true, "visible": true, "heightDp": 50 }
```

Failure does not create an empty persistent region and returns a stable `reason`.

## `hideBanner()`

Removes the current banner and restores the WebView inset. Safe and idempotent when no banner exists.

## `showPrivacyOptions()`

Shows UMP privacy options only when required/available and returns the refreshed consent state.

## Lifecycle invariants

- One banner maximum.
- Navigation away from an eligible surface hides the banner before the new screen becomes active.
- Pro and protected surfaces never invoke `showBanner`.
- Debug builds use Google's sample IDs unless explicitly running an approved test configuration.
- Release builds deny requests when production IDs are absent.

