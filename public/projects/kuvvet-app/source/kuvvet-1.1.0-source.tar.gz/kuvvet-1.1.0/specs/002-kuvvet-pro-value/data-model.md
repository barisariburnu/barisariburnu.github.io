# Data Model: KUVVET 1.1 Pro Value

## Subscription Offer

- `productId`: stable Google Play subscription product ID
- `basePlanId`: monthly or annual base plan
- `offerId`: optional introductory offer
- `offerToken`: checkout token scoped to the fetched offer
- `formattedPrice`: authoritative store-localized display value
- `billingPeriod`: recurring ISO period
- `trialPeriod`: optional store-reported trial period
- `available`: whether checkout may be started

**Validation**: Offers are never cached across launches for checkout. Checkout accepts only an offer
returned by the current store query.

## Verified Entitlement

- `tier`: `free` or `pro`
- `state`: `free`, `active`, `grace`, `cancelled`, `hold`, `expired`, `pending`, `revoked`, or `unknown`
- `entitled`: derived access flag
- `paidThrough`: nullable authoritative expiry time
- `willRenew`: renewal expectation, not an access decision
- `lastVerifiedAt`: trusted verification time
- `capabilities`: available service benefits
- `staleAfter`: time after which an online refresh is required for service-only actions

**Transitions**:

- `pending` → `active` only after trusted verification
- `active` → `grace` keeps access
- `active|grace` → `cancelled` keeps access until `paidThrough`
- `active|grace|cancelled` → `hold|expired|revoked` removes service access and ad suppression after
  authoritative refresh
- Any state with missing/invalid verification metadata normalizes to free

## Purchase Reference

- `purchaseTokenHash`: keyed, non-reversible ownership/deduplication reference
- `purchaseTokenCiphertext`: authenticated encryption of token material for trusted refresh
- `accountRef`: owning KUVVET account
- `productId`: expected product
- `packageName`: `com.gearapps.kuvvet`
- `acknowledgementState`: current store state
- `lastStoreCheckAt`: last successful Developer API lookup

**Validation**: Raw tokens never appear in logs or API responses. Encryption configuration is
required before persistence; a token cannot be attached to a second account.

## Advertising Decision

- `surface`: current logical screen
- `tier`: normalized entitlement tier
- `isNativeAndroid`: platform capability
- `configured`: production/test configuration readiness
- `canRequestAds`: UMP result
- `show`: derived boolean
- `reason`: stable allow/deny reason

**Rules**: Only free + native Android + configured + consent-ready + Library/Plan/Stats yields
`show=true`. Every other combination denies without loading an ad.

## Consent State

- `canRequestAds`: whether UMP currently permits an ad request
- `privacyOptionsRequired`: whether Settings must expose privacy choices
- `status`: `unknown`, `required`, `not-required`, `obtained`, or `unavailable`
- `updatedAt`: last consent information refresh

**Validation**: Unknown and error states deny requests. Consent is refreshed each launch and a
privacy-options entry remains reachable whenever required.

## Cloud Consent

- `enabled`: explicit managed-service opt-in
- `acceptedDisclosureVersion`: privacy disclosure version accepted
- `acceptedAt`: acceptance time
- `dataCategories`: uploaded KUVVET state categories
- `withdrawnAt`: nullable withdrawal time

**Validation**: Entitlement alone never sets `enabled=true`. Withdrawal stops future upload without
deleting local state.

## Sync Envelope

- `schemaVersion`: backwards-compatible envelope version
- `revision`: opaque server revision
- `updatedAt`: server receipt time
- `deviceId`: pseudonymous installation reference
- `state`: compatible KUVVET state payload
- `contentHash`: integrity/deduplication hash

**Transitions**:

- No remote state + opt-in → create revision 1
- Matching client revision → accept update and increment revision
- Missing/mismatched revision → return conflict without overwrite
- Conflict resolution → client submits merged state against latest revision

## Sync Conflict

- `serverRevision`: current remote revision
- `clientRevision`: last observed client revision
- `serverUpdatedAt`: comparison context
- `conflictingKeys`: state regions that could not be safely merged
- `recoverable`: whether deterministic merge can proceed

## Training Insight

- `kind`: `volume`, `consistency`, `exercise-progress`, or `personal-record`
- `range`: selected start/end or supported period
- `sampleCount`: supporting completed records
- `value`: calculated result
- `status`: `ready` or `insufficient-data`
- `explanation`: localized, non-medical interpretation

**Validation**: Insights use completed local records, expose their range/sample sufficiency, and do
not imply diagnosis, injury prevention, or guaranteed performance.

