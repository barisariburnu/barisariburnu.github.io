# Quickstart: Validate KUVVET 1.1 Pro Value

## Prerequisites

- Node.js and Java runtimes documented by the workspace
- Android SDK with API 36
- A test-only publisher service configuration
- Google Play license-test account and configured `kuvvet_pro` monthly/annual base plans for live
  billing validation
- AdMob test application/banner IDs and UMP debug geography for advertising validation

Never use production ads during local or automated testing.

## Automated checks

```bash
cd frontend
npm test
npm run build:mobile

cd ../api
npm test

cd ../frontend/android
JAVA_HOME=/usr/local/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home ./gradlew test assembleDebug
```

Expected: all domain, UI, API, native bridge, and Android build checks pass. Protected-surface tests
observe no ad invocation. No test output contains purchase tokens or service credentials.

## Free-tier advertising scenarios

1. Run the native debug build with Google's sample IDs.
2. Force UMP EEA debug geography and reset consent.
3. Deny consent: Library, Plan, and Stats remain complete and make no banner request.
4. Grant consent: each eligible surface displays at most one banner.
5. Navigate through Home, Workout, History, Settings, and Pro: no ad request occurs.
6. Disable network and repeat: no blank blocking region or navigation delay appears.
7. Open Settings privacy options, withdraw consent, and verify the current banner disappears.

## Entitlement scenarios

For each store test state, compare behavior with
[contracts/billing-entitlement.md](contracts/billing-entitlement.md):

- Active/trial, grace, and cancelled-before-expiry: Pro benefits active and zero ads.
- Pending: explanatory status, no Pro access.
- Hold, expired, refunded, revoked: service features disabled, local data intact.
- Reinstall/second device: Restore recovers a valid verified entitlement without a charge.
- Verifier offline: no new durable access is granted and local workouts remain usable.

## Cloud scenarios

1. Confirm no upload occurs before explicit opt-in.
2. Opt in, upload at least 100 representative records, then restore them on a second device.
3. Edit both devices from the same base revision and verify a `SYNC_CONFLICT` instead of overwrite.
4. Resolve the conflict and confirm completed workouts are not duplicated.
5. Interrupt the service during a workout; finish and inspect the local workout successfully.
6. Expire entitlement; verify local data plus remote export/deletion remain reachable.

## Pro value and insight scenarios

1. Review the free/Pro comparison at 320, 390, and 600 CSS pixels in English and every supported
   LTR locale.
2. Confirm unavailable cloud/service benefits are not sold as active.
3. Seed sufficient and insufficient histories; verify advanced insights either cite range/sample
   data or show an insufficient-data state.
4. Confirm basic Stats remains usable for free users.

## Release gate

Before signing 1.1.0, reconcile in-app behavior with Play Ads, Advertising ID, Data safety,
subscription, privacy-policy, reviewer-access, and app-content declarations. A release containing
Mobile Ads must not retain the 1.0.1 no-ads declaration.

### Privacy and advertising gate

- Confirm no ad request occurs before the current-launch UMP refresh permits it.
- Confirm production builds fail closed when the AdMob app ID or banner unit ID is absent.
- Confirm Privacy options remains reachable when UMP reports it as required.
- Re-submit Play Console Ads, Advertising ID, Data safety, and privacy-policy declarations from the
  behavior of the exact signed bundle; do not copy the 1.0.1 no-ads answers.

### Subscription gate

- Verify checkout displays Google Play's current localized price, billing period, and trial terms.
- Verify the backend owns verification and acknowledgement; client/store state alone grants no Pro.
- Exercise pending, grace, cancelled-paid, hold, expired, revoked, restore, and offline-verifier
  outcomes with license-test accounts before promotion.
- Confirm cancellation or service failure never removes local workouts, plans, history, import, or
  export.

### Rollback gate

- Keep the accepted 1.0.1 AAB, source commit, mapping inputs, upload-key fingerprint, and Play
  declarations with the 1.1.0 release record.
- Stage 1.1.0 through an internal release first and halt rollout on consent, crash, billing,
  entitlement, or sync regressions.
- Play version codes are immutable: rollback means publishing a fixed bundle with a higher version
  code, while the server disables ads/service capabilities through deny-by-default configuration.
