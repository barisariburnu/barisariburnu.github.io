# Research: KUVVET 1.1 Pro Value

## Hybrid free/Pro proposition

**Decision**: Keep complete local training free. Allow one adaptive banner only on Library, Plan,
and Stats after consent. Pro removes every ad and adds opt-in managed backup, cross-device sync, and
advanced insights.

**Rationale**: Ad removal provides an immediate, understandable benefit while service-backed
features provide durable subscription value. Protecting Home and active training avoids degrading
the daily core experience.

**Alternatives considered**: An ad-free free tier provided too little immediate Pro differentiation;
gating local logging violated the constitution; interstitial/rewarded/app-open ads were too
disruptive for a minimal training tool.

## Android advertising SDK

**Decision**: Use Google's maintained Mobile Ads SDK `25.4.0` and UMP `4.0.0` through one native
Capacitor bridge. Development and automated tests use Google's sample identifiers; a production
build is advertising-disabled unless publisher configuration is present.

**Rationale**: Google's current Android setup documentation lists Mobile Ads `25.4.0`, requires an
application ID, and notes the SDK supplies `AD_ID` in merged manifests. Current UMP guidance lists
`4.0.0`, requires consent information refresh on every launch, and requires preventing duplicate
requests when consent becomes requestable through more than one callback.

**Alternatives considered**: A community Capacitor plugin adds a maintenance and policy boundary;
the next-generation SDK remains a broader migration and is unnecessary for this initial AdMob-only
banner scope; a web advertisement inside the WebView would weaken consent and lifecycle control.

**Primary references**:

- https://developers.google.com/admob/android/quick-start
- https://developers.google.com/admob/android/privacy
- https://developers.google.com/admob/android/privacy/gdpr

## Billing and entitlement trust boundary

**Decision**: Keep Google Play Billing `9.1.0`; query offers and purchases on foreground, send
purchase tokens to the authenticated publisher service, verify with the Google Play Developer API,
and grant access only from normalized server responses. Store token material encrypted at rest so
the service can refresh state; store hashes separately for ownership and deduplication. Add
idempotent real-time developer notification handling as a production follow-up in the same service.

**Rationale**: Google documents the sequence as display, checkout, server verification, grant, and
acknowledgement; it also recommends querying purchases after connection and on resume and using a
secure backend. Subscription V2 is the authoritative lifecycle resource.

**Alternatives considered**: Client-only acknowledgement/entitlement is forgeable; storing only a
token hash prevents later lifecycle refresh; relying exclusively on the device misses refunds and
changes that occur while the app is absent.

**Primary references**:

- https://developer.android.com/google/play/billing/integrate
- https://developer.android.com/google/play/billing/backend
- https://developers.google.com/android-publisher/api-ref/rest/v3/purchases.subscriptionsv2/get

## Cloud synchronization model

**Decision**: Evolve the current whole-state upload into a versioned sync envelope with an opaque
revision. Clients update against the last observed revision. A mismatch returns both revision
metadata and a conflict result; a deterministic client helper merges stable-record collections and
requires explicit recovery when a scalar or unidentifiable record cannot be resolved safely.

**Rationale**: This is the smallest compatible extension to the existing API that prevents silent
last-write-wins loss and duplicate completed workouts without introducing a new database.

**Alternatives considered**: Full event sourcing is disproportionate for 1.1.0; unconditional PUT
silently overwrites; automatic timestamp-only merging can lose deliberate edits and is unreliable
across skewed device clocks.

## Advanced insight boundary

**Decision**: Keep current history and basic charts free. Pro adds clearly labeled longer-range
volume, consistency, exercise-progress, and personal-record summaries derived locally from recorded
history. Service analytics are offered only when the managed service is available and consented.

**Rationale**: Local deterministic insights give immediate value without uploading data, while the
service remains optional. An insufficient-data result is safer than fabricated guidance.

**Alternatives considered**: Locking all Stats would remove existing free value; AI-generated
coaching adds medical/safety, cost, and disclosure scope that is not justified for 1.1.0.

## Privacy and store declarations

**Decision**: Advertising remains disabled until AdMob application/ad-unit configuration, UMP
messages, privacy controls, and updated Play declarations are ready. The release must then declare
ads and advertising ID use and update Data safety/privacy disclosures to match actual SDK and cloud
behavior.

**Rationale**: The current 1.0.1 declaration correctly says no ads. Adding the SDK changes runtime
and store disclosures; shipping a half-configured SDK would create policy risk without revenue.

**Alternatives considered**: Enabling SDK initialization before declarations or consent was rejected;
hard-coding production identifiers in source was rejected even though identifiers are not secrets,
because it makes accidental production requests from development builds more likely.

