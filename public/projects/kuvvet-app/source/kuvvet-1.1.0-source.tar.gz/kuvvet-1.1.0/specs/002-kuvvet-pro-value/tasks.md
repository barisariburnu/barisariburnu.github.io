# Tasks: KUVVET 1.1 Pro Value

**Input**: Design documents from `/specs/002-kuvvet-pro-value/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/, quickstart.md

**Tests**: Domain, billing, advertising, synchronization, and insight tests are required by the
KUVVET constitution. Tests are written before their corresponding implementation.

**Organization**: Tasks are grouped by user story so each value slice remains independently
testable.

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Establish the 1.1.0 release identity and safe configuration inputs.

- [X] T001 Bump the web/mobile release identity to 1.1.0 and Android versionCode 3 in frontend/package.json and frontend/android/app/build.gradle
- [X] T002 [P] Extend the documented local credentials schema with test/production AdMob and billing service configuration in credentials.example.json and docs/ANDROID_RELEASE.md
- [X] T003 [P] Add 1.1.0 privacy, advertising, subscription, and rollback gates to specs/002-kuvvet-pro-value/quickstart.md and docs/ANDROID_RELEASE.md

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Shared entitlement, capability, consent, and feature-state foundations.

**⚠️ CRITICAL**: No user-story integration starts before this phase is complete.

- [X] T004 [P] Add failing stale-entitlement and capability access tests in frontend/src/lib/entitlement.test.js
- [X] T005 Extend normalized entitlement capabilities and staleness rules in frontend/src/lib/entitlement.js
- [X] T006 [P] Add failing advertising lifecycle decision tests in frontend/src/lib/monetization.test.js
- [X] T007 Extend advertising decisions with stable configuration/consent/lifecycle reasons in frontend/src/lib/monetization.js
- [X] T008 [P] Add English source keys for Pro comparison, ad privacy, cloud consent, conflicts, and insights in frontend/src/lib/i18n.js and frontend/src/locales/tr.js
- [X] T009 Add a shared runtime monetization state/controller with safe web fallbacks in frontend/src/lib/ads.js and frontend/src/store/useUI.js

**Checkpoint**: Entitlement and advertising decisions are deterministic and reusable.

---

## Phase 3: User Story 1 - Understand the Free and Pro Value (Priority: P1) 🎯 MVP

**Goal**: Make the real free/Pro proposition accurate and understandable before purchase.

**Independent Test**: A free user can identify free local features, ad removal, and each currently
available service benefit; unavailable benefits cannot be sold as active.

### Tests for User Story 1

- [X] T010 [P] [US1] Add Pro benefit availability and truthful-offer component tests in frontend/src/views/Pro.test.jsx

### Implementation for User Story 1

- [X] T011 [US1] Replace static Pro claims with capability-driven free/Pro comparison and availability states in frontend/src/views/Pro.jsx
- [X] T012 [US1] Add minimal responsive comparison, status, and unavailable-benefit styles in frontend/src/index.css
- [X] T013 [US1] Surface store-returned trial/renewal details and prevent checkout when service capabilities are unavailable in frontend/src/views/Pro.jsx
- [X] T014 [US1] Add a Settings entry that explains the active tier, service connection, and restoration route in frontend/src/views/Settings.jsx

**Checkpoint**: The Pro screen is a truthful, independently testable 1.1.0 MVP.

---

## Phase 4: User Story 2 - Use the Free Tier Without Workout Disruption (Priority: P1)

**Goal**: Add restrained, consent-gated Android banners only to approved secondary screens.

**Independent Test**: Free/test users can see at most one banner on Library, Plan, or Stats after
consent; protected surfaces, denied consent, web demo, failure, and Pro states make no ad request.

### Tests for User Story 2

- [X] T015 [P] [US2] Add native bridge configuration and protected-surface unit tests in frontend/android/app/src/test/java/com/gearapps/kuvvet/KuvvetAdsPolicyTest.java
- [X] T016 [P] [US2] Add route-to-banner lifecycle tests with mocked native ads in frontend/src/components/AdSlot.test.jsx

### Implementation for User Story 2

- [X] T017 [US2] Add official Mobile Ads 25.4.0 and UMP 4.0.0 dependencies plus debug/release manifest placeholders in frontend/android/app/build.gradle and frontend/android/app/src/main/AndroidManifest.xml
- [X] T018 [US2] Implement consent refresh, one-banner lifecycle, test IDs, privacy options, and deny-by-default release configuration in frontend/android/app/src/main/java/com/gearapps/kuvvet/KuvvetAdsPlugin.java
- [X] T019 [US2] Register the native advertising bridge in frontend/android/app/src/main/java/com/gearapps/kuvvet/MainActivity.java
- [X] T020 [US2] Create the route-aware zero-layout-shift advertising coordinator in frontend/src/components/AdSlot.jsx
- [X] T021 [US2] Mount advertising coordination for Library, Plan, and Stats while explicitly hiding it elsewhere in frontend/src/App.jsx
- [X] T022 [US2] Add privacy-options control and advertising disclosure in frontend/src/views/Settings.jsx

**Checkpoint**: Advertising is testable independently and cannot enter protected flows.

---

## Phase 5: User Story 3 - Gain and Restore Verified Pro Access (Priority: P2)

**Goal**: Make verified subscription lifecycle state durable, refreshable, and ad-suppressing.

**Independent Test**: Active/trial/grace/cancelled-paid states enable Pro; pending/hold/expired/
refunded/revoked/unverified states do not; Restore recovers access without a second charge.

### Tests for User Story 3

- [X] T023 [P] [US3] Add encrypted-token round-trip, redaction, ownership, refresh, and stale-state tests in api/billing.test.js
- [X] T024 [P] [US3] Add purchase foreground-query and verified-update tests in frontend/src/lib/billing.test.js
- [X] T025 [P] [US3] Add Android purchase restore/foreground contract tests in frontend/android/app/src/test/java/com/gearapps/kuvvet/KuvvetBillingPolicyTest.java

### Implementation for User Story 3

- [X] T026 [US3] Add authenticated encryption and redacted refresh records for purchase tokens in api/billing.js
- [X] T027 [US3] Refresh stale entitlements through the Google Play verifier and expose capability availability in api/server.js
- [X] T028 [US3] Add initial-purchase acknowledgement through the trusted verifier path in api/billing.js and api/server.js
- [X] T029 [US3] Query existing purchases after billing connection/foreground and emit stable updates in frontend/android/app/src/main/java/com/gearapps/kuvvet/KuvvetBillingPlugin.java
- [X] T030 [US3] Refresh/restore server-verified entitlement on app foreground and drive ad suppression in frontend/src/lib/billing.js and frontend/src/App.jsx
- [X] T031 [US3] Display pending, grace, cancelled-paid, hold, expiry, stale, and restore outcomes in frontend/src/views/Pro.jsx

**Checkpoint**: Pro access is trusted, restorable, and consistently suppresses ads.

---

## Phase 6: User Story 4 - Use Pro Cloud Convenience Safely (Priority: P2)

**Goal**: Provide explicit opt-in, revision-safe managed backup and synchronization.

**Independent Test**: Two devices synchronize 100 representative records without duplicate
workouts or silent overwrite; local logging succeeds during failure and export/deletion remain
reachable after expiry.

### Tests for User Story 4

- [X] T032 [P] [US4] Add deterministic merge, deduplication, legacy envelope, and conflict tests in frontend/src/lib/sync.test.js
- [X] T033 [P] [US4] Add sync consent, entitlement, revision conflict, export, and delete API tests in api/sync.test.js

### Implementation for User Story 4

- [X] T034 [US4] Implement stable-record merge and explicit unresolved-conflict results in frontend/src/lib/sync.js
- [X] T035 [US4] Implement versioned sync envelopes, revision checks, consent records, export, and remote deletion in api/sync.js
- [X] T036 [US4] Add authenticated `/api/sync` GET/PUT/DELETE/export routes with Pro service gating in api/server.js
- [X] T037 [US4] Add sync client transport, local revision persistence, offline queueing, and recovery in frontend/src/lib/remote.js and frontend/src/lib/mobile.js
- [X] T038 [US4] Add cloud disclosure, opt-in, status, conflict recovery, export, and deletion controls in frontend/src/views/Settings.jsx

**Checkpoint**: Managed cloud convenience is opt-in and never weakens local ownership.

---

## Phase 7: User Story 5 - Review Advanced Training Insights (Priority: P3)

**Goal**: Add repeat Pro value through deterministic, non-medical training trends.

**Independent Test**: Sufficient histories yield range/sample-backed insights; insufficient
histories yield an explicit empty state; free basic statistics remain intact.

### Tests for User Story 5

- [X] T039 [P] [US5] Add volume, consistency, exercise-progress, personal-record, and insufficient-data tests in frontend/src/lib/pro-insights.test.js
- [X] T040 [P] [US5] Add free-versus-Pro insight visibility tests in frontend/src/views/Stats.pro.test.jsx

### Implementation for User Story 5

- [X] T041 [US5] Implement deterministic insight summaries with range/sample metadata in frontend/src/lib/pro-insights.js
- [X] T042 [US5] Add a capability-gated advanced insight region without changing free basic statistics in frontend/src/views/Stats.jsx
- [X] T043 [US5] Add minimal insight preview, lock, and insufficient-data styles in frontend/src/index.css

**Checkpoint**: Advanced insights add ongoing Pro value without hiding existing free data.

---

## Phase 8: Polish & Cross-Cutting Concerns

**Purpose**: Complete localization, accessibility, disclosure, build, and release evidence.

- [X] T044 [P] Fill or verify every new English key across supported LTR locale packs with fallback tests in frontend/src/locales/ and frontend/src/lib/i18n-core.test.js
- [X] T045 Verify 48-pixel targets, reduced motion, inset handling, and 320/390/600-pixel layouts for Pro, Settings, Stats, and eligible ad surfaces in specs/002-kuvvet-pro-value/design-qa.md
- [X] T046 Reconcile privacy policy, Data safety, Ads, Advertising ID, subscription, source, and reviewer declarations in docs/ANDROID_RELEASE.md and the publisher Pages content
- [ ] T047 Run every automated command and manual scenario in specs/002-kuvvet-pro-value/quickstart.md and record results in specs/002-kuvvet-pro-value/validation.md
- [X] T048 Build the signed 1.1.0 release bundle and record version, SHA-256, signing identity, and rollback artifact in docs/ANDROID_RELEASE.md

---

## Dependencies & Execution Order

### Phase Dependencies

- Setup has no dependency.
- Foundational depends on Setup and blocks every story.
- US1 and US2 can proceed after Foundational; US1 is the smallest commercial MVP.
- US3 depends on Foundational and integrates with US1/US2 for checkout and ad suppression.
- US4 depends on verified service capabilities from US3.
- US5 depends only on entitlement capabilities and can proceed alongside US4.
- Polish depends on the stories selected for the 1.1.0 release candidate.

### User Story Dependencies

- **US1 (P1)**: Foundational only.
- **US2 (P1)**: Foundational only; Pro suppression completes with US3.
- **US3 (P2)**: Foundational; integrates into US1 and US2.
- **US4 (P2)**: US3 verified service capability.
- **US5 (P3)**: Foundational entitlement capability; no cloud dependency.

### Parallel Opportunities

- T002/T003, T004/T006/T008, and story test tasks marked `[P]` touch independent files.
- After Phase 2, US1 UI and US2 native bridge can progress independently.
- API billing tests and Android billing tests in US3 can progress independently.
- US5 insight logic can progress while US4 sync/API work is underway.

## Parallel Example: User Story 2

```text
Task: T015 Add native bridge policy tests in KuvvetAdsPolicyTest.java
Task: T016 Add route lifecycle tests in AdSlot.test.jsx
```

## Parallel Example: User Story 3

```text
Task: T023 Add API token/refresh tests in api/billing.test.js
Task: T024 Add frontend billing update tests in frontend/src/lib/billing.test.js
Task: T025 Add Android billing policy tests in KuvvetBillingPolicyTest.java
```

## Implementation Strategy

### MVP First

1. Complete Setup and Foundational.
2. Complete US1 so the Pro proposition is truthful before enabling checkout.
3. Complete US2 with test identifiers and deny-by-default production configuration.
4. Validate both slices independently before adding server-backed benefits.

### Incremental Delivery

1. Accurate free/Pro comparison.
2. Consent-gated free-tier banners and Pro ad suppression.
3. Trusted, refreshable subscription lifecycle.
4. Opt-in managed sync.
5. Advanced deterministic insights.
6. Store disclosure reconciliation and signed bundle.

## Format Validation

All 48 tasks use the required checkbox and sequential ID format, include `[P]` only where work can
run independently, include `[US#]` in user-story phases, and name concrete file paths.
