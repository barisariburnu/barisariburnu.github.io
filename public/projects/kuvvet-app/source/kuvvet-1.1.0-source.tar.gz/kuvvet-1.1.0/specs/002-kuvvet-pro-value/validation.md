# KUVVET 1.1 Validation Record

**Candidate**: 1.1.0 (`versionCode 3`)  
**Validated**: 2026-08-31  
**Package**: `com.gearapps.kuvvet`

## Automated gates

| Gate | Result | Evidence |
|---|---|---|
| Frontend domain/UI | Pass | 51 files, 599 tests |
| API billing/sync/auth | Pass | 19 tests |
| Mobile web build + Capacitor sync | Pass | Vite production build, 139 modules, Android assets synchronized |
| Android unit + debug build | Pass | Gradle `test assembleDebug`, 324 tasks |
| Android release lint | Pass | 0 errors, 35 non-blocking generated/icon warnings |
| Signed release bundle | Pass | `bundleRelease`; JAR signature verified |
| Publisher Pages | Pass | Next.js production export, 14 static routes including KUVVET legal pages |
| Diff hygiene | Pass | `git diff --check` |

## Responsive and accessibility gates

- Stats, Pro, and Settings passed live 320×844, 390×844, and 600×844 checks without horizontal
  overflow; see `design-qa.md`.
- Critical interactive targets are at least 48 CSS pixels; reduced-motion and safe-area rules are
  present.
- English source/fallback and all supported LTR locale packs passed the Pro-value contract test;
  RTL locale codes remain excluded.

## Scenario coverage

- Advertising route, consent, configuration, lifecycle, failure, and Pro-suppression decisions are
  automated with mocked native ads. Debug uses Google's sample identifiers. Release configuration
  is fail-closed because production AdMob app/banner IDs are not yet present in local credentials.
- Entitlement tests cover active, grace, paid-through cancellation, pending, hold, expired, revoked,
  stale, restore, foreground query, ownership, acknowledgement, and redaction behavior.
- Synchronization tests cover explicit consent, capability gating, deterministic merge,
  deduplication, legacy envelopes, revision conflicts, export, and remote deletion.
- Insight tests cover volume, consistency, exercise progress, personal records, range/sample
  metadata, insufficient data, and free-versus-Pro visibility.

## External scenarios still required before rollout

These cannot be truthfully marked complete from the local environment:

1. Configure live AdMob application/banner IDs and UMP messages, then exercise grant, denial,
   withdrawal, offline, and one-banner-per-eligible-surface behavior on a physical Android device.
2. Deploy the HTTPS verifier with persistent storage, service-account access, token-encryption key,
   and the exact capability allowlist.
3. Create/activate `kuvvet_pro` monthly and annual base plans and exercise localized price/trial,
   purchase, pending, restore, grace, cancellation, hold, expiry, and revoke with a Play license
   tester.
4. Run a two-device 100-record managed-cloud restore/conflict/recovery scenario against production.
5. Re-submit Ads, Advertising ID, Data safety, subscription, reviewer-access, and privacy declarations
   for the exact versionCode 3 bundle before Play review.

## Release artifact

- File: `/Users/baris/.kuvvet-release/kuvvet-1.1.0.aab`
- Size: 9,287,993 bytes
- SHA-256: `34d5ef94efd34b71bc00a4403e9e9851c5bae9759ebd831b2d7368400ffd4c9c`
- Upload certificate SHA-256:
  `83:A6:4E:37:B6:89:C1:34:88:5D:D8:07:41:8B:45:24:CA:99:2F:AE:CC:68:1C:B8:1E:C0:2F:F3:BA:87:D9:9C`
- Rollback artifact: `kuvvet-1.0.1.aab`, SHA-256
  `aa09592d85405b5d4dd2ff61d03b20dc6447d8c6649bb8d45204e71f000fa60b`
