# Implementation Plan: KUVVET 1.1 Pro Value

**Branch**: `002-kuvvet-pro-value` | **Date**: 2026-08-31 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/002-kuvvet-pro-value/spec.md`

## Summary

KUVVET 1.1.0 will turn the existing Pro presentation and bridge contracts into a coherent hybrid
freemium product. Free local training remains complete. Consent-gated adaptive banners may appear
only on Library, Plan, and Stats; verified Pro removes all advertising and unlocks opt-in managed
backup/synchronization plus advanced insight views. Google Play remains the purchase authority,
while a publisher-operated service verifies purchase tokens before granting durable entitlements.
All integrations degrade to the existing local-first experience when unavailable.

## Technical Context

**Language/Version**: JavaScript ES modules on Node.js 22; React 19; Java 17-compatible Android
sources built with the repository's configured Android toolchain

**Primary Dependencies**: Capacitor 7.6, React Router 7, Zustand 5, Google Play Billing 9.1.0,
Google Mobile Ads SDK 25.4.0, Google UMP 4.0.0, Node built-ins, existing WebAuthn and Web Push
dependencies

**Storage**: Existing on-device persisted KUVVET state; publisher service JSON records written
atomically, extended with versioned sync envelopes, encrypted purchase-token material, and
entitlement metadata

**Testing**: Vitest for frontend/domain logic, Node's test runner for API logic and contracts,
JUnit for Android bridge units, Gradle Android checks, browser-rendered interaction validation

**Target Platform**: Android 6.0+ (API 23), target/compile SDK 36, with a web-safe demo fallback

**Project Type**: Capacitor Android application plus React frontend and a publisher-operated Node
service

**Performance Goals**: Primary navigation and workout actions never wait for ads, billing, or
cloud services; ad eligibility resolves without visible layout shift; local writes remain
immediate; 100-record synchronization completes within 10 seconds on a normal mobile connection

**Constraints**: Core features must work offline; no entitlement may be granted from client state
alone; no production ad request before valid configuration and consent; no ad on protected
surfaces; no secret in the web bundle or repository; English-first LTR only; existing data formats
remain readable

**Scale/Scope**: One Android app, one publisher service, two subscription base plans, three eligible
ad surfaces, five protected surfaces, existing major LTR locales, and per-user training datasets
within the existing 20 MB backup limit

## Constitution Check

*GATE: Passed before research and passed again after design.*

- **Open Source and License Integrity — PASS**: Application and service changes remain
  AGPL-3.0-or-later. Google SDK terms are dependency notices, not a relicensing of project code.
  No purchased exercise-media payload enters the source repository.
- **Local-First Privacy — PASS**: Local logging, history, basic statistics, import, export, and
  deletion remain free and offline. Cloud is explicit opt-in and failure never blocks local writes.
- **English-First LTR Internationalization — PASS**: New copy uses English translation keys and the
  current supported LTR catalog; RTL remains excluded.
- **Tested Domain Logic — PASS**: Advertising decisions, entitlement normalization, sync conflict
  resolution, and insight availability are deterministic helpers with automated tests. Durable Pro
  access uses trusted service verification.
- **Minimal, Accessible Mobile UX — PASS**: Ads are limited to one secondary region, paywall and
  consent actions retain 48-pixel targets, and active training surfaces remain distraction-free.
- **Product and Monetization — PASS**: Google Play Billing is authoritative, localized store values
  are displayed, free private logging remains complete, and Pro value is service-backed.
- **Delivery and Quality Gates — PASS**: The quickstart covers frontend, API, Android, offline,
  consent, billing-state, localization, and store-disclosure validation.

## Project Structure

### Documentation (this feature)

```text
specs/002-kuvvet-pro-value/
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/
│   ├── ads-bridge.md
│   ├── billing-entitlement.md
│   └── cloud-sync.md
└── tasks.md
```

### Source Code (repository root)

```text
frontend/
├── src/
│   ├── components/
│   ├── lib/
│   ├── locales/
│   ├── store/
│   └── views/
└── android/app/
    ├── build.gradle
    └── src/
        ├── main/AndroidManifest.xml
        ├── main/java/com/gearapps/kuvvet/
        └── test/java/com/gearapps/kuvvet/

api/
├── billing.js
├── server.js
└── *.test.js
```

**Structure Decision**: Extend the existing React/Capacitor frontend, its native Android bridge
package, and the existing publisher API. No additional application or runtime service is introduced.

## Phase 0: Research Decisions

Research is recorded in [research.md](research.md). All dependency, consent, billing trust-boundary,
sync, disclosure, and rollout questions are resolved; no clarification markers remain.

## Phase 1: Design

- [data-model.md](data-model.md) defines subscription offers, verified entitlement, advertising
  decisions, consent state, encrypted purchase references, synchronization envelopes/conflicts, and
  training insights.
- [contracts/ads-bridge.md](contracts/ads-bridge.md) defines the web/native consent and banner
  boundary.
- [contracts/billing-entitlement.md](contracts/billing-entitlement.md) defines verified purchase and
  entitlement responses.
- [contracts/cloud-sync.md](contracts/cloud-sync.md) defines opt-in versioned backup/sync behavior.
- [quickstart.md](quickstart.md) defines runnable release validation.

## Post-Design Constitution Re-check

**PASS**. The design keeps new runtime dependencies to the two official Google advertising/privacy
artifacts, documents their maintenance and bundle impact, retains trusted billing verification,
adds explicit cloud consent/export/deletion contracts, and preserves local/offline behavior.

## Complexity Tracking

No constitution violations or additional project layers require justification.

