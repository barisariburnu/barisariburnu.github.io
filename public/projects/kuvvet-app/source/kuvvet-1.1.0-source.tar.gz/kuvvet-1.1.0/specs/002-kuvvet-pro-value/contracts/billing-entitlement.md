# Contract: Billing and Entitlement

## `GET /api/billing/account-reference`

Authenticated response:

```json
{ "obfuscatedAccountId": "stable-nonidentifying-reference" }
```

## `POST /api/billing/verify`

Authenticated request:

```json
{
  "packageName": "com.gearapps.kuvvet",
  "productId": "kuvvet_pro",
  "purchaseToken": "store-token"
}
```

The service validates product/package/ownership, queries the Google Play Developer API, persists
only protected token material, acknowledges eligible initial purchases, and returns the normalized
Verified Entitlement. Pending and unverified states never grant access.

## `GET /api/billing/entitlement?refresh=auto`

Returns the most recent normalized entitlement. When protected token material is available and the
record is stale, the service refreshes it before responding; transient store failure returns the
last verified record marked stale and denies new service-only operations after `staleAfter`.

## Stable errors

- `PRODUCT_MISMATCH`
- `PURCHASE_INVALID`
- `PURCHASE_OWNED`
- `VERIFIER_NOT_CONFIGURED`
- `STORE_UNAVAILABLE`
- `TOKEN_PROTECTION_NOT_CONFIGURED`
- `AUTH_REQUIRED`

No error contains a raw purchase token, credential, or Google response body.

## Access matrix

| State | Ad-free | Service benefits | Local features |
|---|---:|---:|---:|
| active / trial | yes | yes | yes |
| grace | yes | yes | yes |
| cancelled before paid-through | yes | yes | yes |
| pending / unknown | no | no | yes |
| hold / expired / revoked | no | no | yes |

