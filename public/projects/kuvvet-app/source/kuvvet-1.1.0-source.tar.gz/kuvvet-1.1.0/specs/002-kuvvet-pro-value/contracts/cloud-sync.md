# Contract: Managed Cloud Sync

All routes require an authenticated account, verified Pro service capability, and explicit cloud
consent. Account export/deletion remains available after entitlement expiry.

## `GET /api/sync`

Returns `204` when no remote state exists, otherwise:

```json
{
  "schemaVersion": 1,
  "revision": "opaque-revision",
  "updatedAt": "2026-08-31T00:00:00.000Z",
  "state": {},
  "contentHash": "sha256"
}
```

## `PUT /api/sync`

```json
{
  "schemaVersion": 1,
  "baseRevision": "opaque-revision-or-null",
  "deviceId": "pseudonymous-installation-id",
  "state": {}
}
```

Matching revision returns the next envelope. A mismatch returns `409 SYNC_CONFLICT` with current
revision metadata and the current state required for deterministic client merge; it never overwrites.

## `GET /api/sync/export`

Returns a portable KUVVET backup for the authenticated account, including after Pro expiry.

## `DELETE /api/sync`

Deletes remote synchronized state and cloud consent records but not local device data, purchase
history required for financial/legal obligations, or the KUVVET account itself.

## Merge invariants

- Completed workouts deduplicate by stable identity and compatible content hash.
- New identifiable records from both sides are preserved.
- Deleted/edited conflicts that cannot be proven safe require an explicit user choice.
- Legacy whole-state data remains readable and is upgraded on the next successful write.
- Local writes proceed regardless of sync outcome.

