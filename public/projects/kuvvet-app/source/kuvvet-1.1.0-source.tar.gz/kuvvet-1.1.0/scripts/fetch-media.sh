#!/usr/bin/env bash
# Manually download the exercise images (JPG) and animations (GIF) into ./media.
# You normally DON'T need this — `docker compose up` fetches them automatically.
# Source mirror: the exact hasaneyldrm/exercises-dataset revision used by openGym's mobile/demo
# media resolver. The media is not MIT licensed; run this only when the KUVVET publisher holds a
# commercial license that covers these files. See NOTICE.md.
set -euo pipefail
cd "$(dirname "$0")/.."
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
cat <<'EOF'
↓ Downloading exercise media (~140 MB) from github.com/hasaneyldrm/exercises-dataset
  Metadata and instruction text: MIT.
  Images and animations: © Gym visual — https://gymvisual.com/
  Source revision used by openGym: 7455efae41b330c265e7cd4b78dfa848e7ce5ebd
  This mirror is not itself a license. Archive the publisher's commercial license and receipt.
EOF
archive="$tmp/source.tar.gz"
source_dir="$tmp/source"
mkdir -p "$source_dir"
curl -fsSL \
  https://codeload.github.com/hasaneyldrm/exercises-dataset/tar.gz/7455efae41b330c265e7cd4b78dfa848e7ce5ebd \
  -o "$archive"
tar -xzf "$archive" --strip-components=1 -C "$source_dir"
mkdir -p media/img media/gif
cp "$source_dir"/images/*.jpg media/img/
cp "$source_dir"/videos/*.gif media/gif/
echo "✓ $(ls media/img | wc -l) images, $(ls media/gif | wc -l) GIFs"
