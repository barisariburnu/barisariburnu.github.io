import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createGooglePlayVerifier,
  defaultEntitlement,
  entitlementAt,
  normalizeGoogleSubscription,
  purchaseTokenHash,
  redactBillingValue,
} from './billing.js';

const now = Date.parse('2026-08-26T10:00:00.000Z');
const future = '2026-09-26T10:00:00.000Z';
const past = '2026-07-26T10:00:00.000Z';
const lineItem = (expiryTime = future, autoRenewEnabled = true) => ({
  productId: 'kuvvet_pro',
  expiryTime,
  autoRenewingPlan: { autoRenewEnabled },
  offerDetails: { basePlanId: 'monthly' },
});

test('normalizes only active, grace, and paid-through cancelled subscriptions as entitled', () => {
  const active = normalizeGoogleSubscription({
    subscriptionState: 'SUBSCRIPTION_STATE_ACTIVE',
    acknowledgementState: 'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED',
    lineItems: [lineItem()],
  }, { productId: 'kuvvet_pro', now });
  assert.deepEqual(active.entitlement, {
    tier: 'pro', state: 'active', entitled: true, paidThrough: future,
    willRenew: true, lastVerifiedAt: new Date(now).toISOString(),
    capabilities: ['managed_backup', 'cross_device_sync', 'service_analytics'],
  });

  const grace = normalizeGoogleSubscription({
    subscriptionState: 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD',
    acknowledgementState: 'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED',
    lineItems: [lineItem()],
  }, { productId: 'kuvvet_pro', now });
  assert.equal(grace.entitlement.state, 'grace');
  assert.equal(grace.entitlement.entitled, true);

  const cancelled = normalizeGoogleSubscription({
    subscriptionState: 'SUBSCRIPTION_STATE_CANCELED',
    acknowledgementState: 'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED',
    lineItems: [lineItem(future, false)],
  }, { productId: 'kuvvet_pro', now });
  assert.equal(cancelled.entitlement.state, 'cancelled');
  assert.equal(cancelled.entitlement.entitled, true);
  assert.equal(cancelled.entitlement.willRenew, false);
});

test('fails closed for pending, hold, expired, revoked, unknown, and mismatched products', () => {
  const cases = [
    ['SUBSCRIPTION_STATE_PENDING', 'pending'],
    ['SUBSCRIPTION_STATE_ON_HOLD', 'hold'],
    ['SUBSCRIPTION_STATE_PAUSED', 'hold'],
    ['SUBSCRIPTION_STATE_EXPIRED', 'expired'],
    ['SUBSCRIPTION_STATE_PENDING_PURCHASE_CANCELED', 'revoked'],
    ['SUBSCRIPTION_STATE_UNSPECIFIED', 'unknown'],
  ];
  for (const [subscriptionState, state] of cases) {
    const normalized = normalizeGoogleSubscription({
      subscriptionState,
      acknowledgementState: 'ACKNOWLEDGEMENT_STATE_PENDING',
      lineItems: [lineItem(past, false)],
    }, { productId: 'kuvvet_pro', now });
    assert.equal(normalized.entitlement.state, state);
    assert.equal(normalized.entitlement.entitled, false);
    assert.deepEqual(normalized.entitlement.capabilities, []);
  }
  assert.throws(() => normalizeGoogleSubscription({ lineItems: [lineItem()] }, {
    productId: 'another_product', now,
  }), /product/i);
});

test('expires a cached time-bounded entitlement and defaults safely', () => {
  assert.deepEqual(defaultEntitlement(), {
    tier: 'free', state: 'free', entitled: false, paidThrough: null,
    willRenew: false, lastVerifiedAt: null, capabilities: [],
  });
  const expired = entitlementAt({
    tier: 'pro', state: 'cancelled', entitled: true, paidThrough: past,
    willRenew: false, lastVerifiedAt: future,
    capabilities: ['managed_backup'],
  }, now);
  assert.equal(expired.state, 'expired');
  assert.equal(expired.entitled, false);
  assert.deepEqual(expired.capabilities, []);
});

test('hashes and redacts purchase tokens without retaining a raw token', () => {
  const raw = 'a-very-sensitive-google-play-purchase-token';
  const hash = purchaseTokenHash(raw, 'server-side-secret');
  assert.match(hash, /^[a-f0-9]{64}$/);
  assert.ok(!hash.includes(raw));
  assert.deepEqual(redactBillingValue({ purchaseToken: raw, nested: [{ token: raw }], safe: 'ok' }), {
    purchaseToken: '[REDACTED]', nested: [{ token: '[REDACTED]' }], safe: 'ok',
  });
});

test('verifies with subscriptionsv2 and acknowledges a new purchase using mocked Google APIs', async () => {
  const calls = [];
  const fetchImpl = async (url, options = {}) => {
    calls.push({ url: String(url), options });
    if (String(url).includes('oauth2.googleapis.com/token')) {
      return new Response(JSON.stringify({ access_token: 'access', expires_in: 3600 }), { status: 200 });
    }
    if (String(url).includes('subscriptionsv2/tokens')) {
      return new Response(JSON.stringify({
        subscriptionState: 'SUBSCRIPTION_STATE_ACTIVE',
        acknowledgementState: 'ACKNOWLEDGEMENT_STATE_PENDING',
        externalAccountIdentifiers: { obfuscatedExternalAccountId: 'account-ref' },
        lineItems: [lineItem()],
      }), { status: 200 });
    }
    if (String(url).endsWith(':acknowledge')) return new Response(null, { status: 204 });
    throw new Error(`unexpected URL: ${url}`);
  };
  const verifier = createGooglePlayVerifier({
    serviceAccount: {
      client_email: 'billing@example.invalid',
      private_key: `-----BEGIN PRIVATE KEY-----\nMC4CAQAwBQYDK2VwBCIEIP9jTZJ3ZBMXzaLUcBCIlxuSdo4wgY79RJ60wihcDnJL\n-----END PRIVATE KEY-----\n`,
    },
    fetchImpl,
    now: () => now,
    signJwt: () => 'signed-jwt-for-test',
  });
  const result = await verifier.verify({
    packageName: 'com.gearapps.kuvvet', productId: 'kuvvet_pro', purchaseToken: 'token-value',
    expectedAccountId: 'account-ref',
  });
  assert.equal(result.entitlement.entitled, true);
  assert.equal(calls.length, 3);
  assert.match(calls[1].url, /subscriptionsv2\/tokens\/token-value$/);
  assert.match(calls[2].url, /subscriptions\/kuvvet_pro\/tokens\/token-value:acknowledge$/);
  assert.equal(calls[2].options.method, 'POST');
});

test('store failures expose stable errors without purchase-token leakage', async () => {
  const raw = 'secret-token-that-must-not-appear';
  const verifier = createGooglePlayVerifier({
    serviceAccount: { client_email: 'billing@example.invalid', private_key: 'unused' },
    fetchImpl: async url => String(url).includes('oauth2')
      ? new Response(JSON.stringify({ access_token: 'access', expires_in: 3600 }), { status: 200 })
      : new Response(JSON.stringify({ error: { message: `bad token ${raw}` } }), { status: 500 }),
    now: () => now,
    signJwt: () => 'signed-jwt-for-test',
  });
  await assert.rejects(
    verifier.verify({ packageName: 'com.gearapps.kuvvet', productId: 'kuvvet_pro', purchaseToken: raw }),
    error => error.code === 'STORE_UNAVAILABLE' && !error.message.includes(raw),
  );
});
