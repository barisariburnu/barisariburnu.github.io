import crypto from 'node:crypto';

export const PRO_CAPABILITIES = Object.freeze([
  'managed_backup',
  'cross_device_sync',
  'service_analytics',
]);

const GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token';
const GOOGLE_PUBLISHER_SCOPE = 'https://www.googleapis.com/auth/androidpublisher';

export class BillingError extends Error {
  constructor(code, message, { status = 503, retryable = false } = {}) {
    super(message);
    this.name = 'BillingError';
    this.code = code;
    this.status = status;
    this.retryable = retryable;
  }
}

export function defaultEntitlement() {
  return {
    tier: 'free',
    state: 'free',
    entitled: false,
    paidThrough: null,
    willRenew: false,
    lastVerifiedAt: null,
    capabilities: [],
  };
}

export function entitlementAt(value, now = Date.now()) {
  if (!value || typeof value !== 'object') return defaultEntitlement();
  const paidThrough = value.paidThrough ? Date.parse(value.paidThrough) : NaN;
  if (value.entitled && Number.isFinite(paidThrough) && paidThrough <= now) {
    return {
      ...defaultEntitlement(),
      state: 'expired',
      paidThrough: value.paidThrough,
      lastVerifiedAt: value.lastVerifiedAt || null,
    };
  }
  return {
    tier: value.entitled ? 'pro' : 'free',
    state: String(value.state || 'unknown'),
    entitled: value.entitled === true,
    paidThrough: value.paidThrough || null,
    willRenew: value.willRenew === true,
    lastVerifiedAt: value.lastVerifiedAt || null,
    capabilities: value.entitled === true ? [...PRO_CAPABILITIES] : [],
  };
}

function stateFromGoogle(state) {
  return ({
    SUBSCRIPTION_STATE_PENDING: 'pending',
    SUBSCRIPTION_STATE_ACTIVE: 'active',
    SUBSCRIPTION_STATE_PAUSED: 'hold',
    SUBSCRIPTION_STATE_IN_GRACE_PERIOD: 'grace',
    SUBSCRIPTION_STATE_ON_HOLD: 'hold',
    SUBSCRIPTION_STATE_CANCELED: 'cancelled',
    SUBSCRIPTION_STATE_EXPIRED: 'expired',
    SUBSCRIPTION_STATE_PENDING_PURCHASE_CANCELED: 'revoked',
  })[state] || 'unknown';
}

export function normalizeGoogleSubscription(storeValue, { productId, now = Date.now() }) {
  if (!storeValue || typeof storeValue !== 'object') {
    throw new BillingError('STORE_RESPONSE_INVALID', 'Google Play returned an invalid subscription', { retryable: true });
  }
  const matchingItems = Array.isArray(storeValue.lineItems)
    ? storeValue.lineItems.filter(item => item?.productId === productId)
    : [];
  if (!matchingItems.length) {
    throw new BillingError('PRODUCT_MISMATCH', 'The verified purchase does not contain the configured product', { status: 400 });
  }
  const item = matchingItems.reduce((latest, candidate) => {
    const a = Date.parse(latest?.expiryTime || 0) || 0;
    const b = Date.parse(candidate?.expiryTime || 0) || 0;
    return b > a ? candidate : latest;
  }, matchingItems[0]);
  const paidThroughMs = Date.parse(item.expiryTime || '');
  const paidThrough = Number.isFinite(paidThroughMs) ? new Date(paidThroughMs).toISOString() : null;
  let state = stateFromGoogle(storeValue.subscriptionState);
  let entitled = state === 'active' || state === 'grace' || (state === 'cancelled' && paidThroughMs > now);
  if (entitled && Number.isFinite(paidThroughMs) && paidThroughMs <= now) {
    state = 'expired';
    entitled = false;
  }
  const willRenew = item.autoRenewingPlan?.autoRenewEnabled === true;
  const entitlement = {
    tier: entitled ? 'pro' : 'free',
    state,
    entitled,
    paidThrough,
    willRenew,
    lastVerifiedAt: new Date(now).toISOString(),
    capabilities: entitled ? [...PRO_CAPABILITIES] : [],
  };
  return {
    entitlement,
    purchase: {
      productId,
      basePlanId: item.offerDetails?.basePlanId || null,
      state: state === 'pending' ? 'pending' : state === 'revoked' ? 'revoked' : state === 'cancelled' ? 'cancelled' : 'purchased',
      acknowledged: storeValue.acknowledgementState === 'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED',
      purchasedAt: storeValue.startTime || null,
      verifiedAt: entitlement.lastVerifiedAt,
    },
  };
}

export function purchaseTokenHash(token, secret) {
  return crypto.createHmac('sha256', String(secret)).update(String(token)).digest('hex');
}

export function redactBillingValue(value) {
  if (Array.isArray(value)) return value.map(redactBillingValue);
  if (!value || typeof value !== 'object') return value;
  const output = {};
  for (const [key, child] of Object.entries(value)) {
    output[key] = /(?:purchase)?token|authorization|private.?key/i.test(key)
      ? '[REDACTED]'
      : redactBillingValue(child);
  }
  return output;
}

function encodedJson(value) {
  return Buffer.from(JSON.stringify(value)).toString('base64url');
}

function defaultSignJwt(unsigned, privateKey) {
  return crypto.sign('RSA-SHA256', Buffer.from(unsigned), privateKey).toString('base64url');
}

async function jsonOrError(response) {
  const text = await response.text();
  if (!text) return {};
  try { return JSON.parse(text); }
  catch { throw new BillingError('STORE_RESPONSE_INVALID', 'Google Play returned a malformed response', { retryable: true }); }
}

export function createGooglePlayVerifier({
  serviceAccount,
  fetchImpl = globalThis.fetch,
  now = Date.now,
  signJwt = defaultSignJwt,
}) {
  if (!serviceAccount?.client_email || !serviceAccount?.private_key) {
    throw new BillingError('VERIFIER_NOT_CONFIGURED', 'Google Play verification credentials are not configured');
  }
  if (typeof fetchImpl !== 'function') {
    throw new BillingError('VERIFIER_NOT_CONFIGURED', 'This server runtime does not provide fetch');
  }
  let cachedAccessToken = null;
  let accessTokenExpiresAt = 0;

  async function accessToken() {
    const timestamp = now();
    if (cachedAccessToken && timestamp < accessTokenExpiresAt - 60_000) return cachedAccessToken;
    const issuedAt = Math.floor(timestamp / 1000);
    const unsigned = `${encodedJson({ alg: 'RS256', typ: 'JWT' })}.${encodedJson({
      iss: serviceAccount.client_email,
      scope: GOOGLE_PUBLISHER_SCOPE,
      aud: GOOGLE_TOKEN_URL,
      iat: issuedAt,
      exp: issuedAt + 3600,
    })}`;
    let assertion;
    try { assertion = `${unsigned}.${signJwt(unsigned, serviceAccount.private_key)}`; }
    catch { throw new BillingError('VERIFIER_NOT_CONFIGURED', 'Google Play verification credentials are invalid'); }
    const response = await fetchImpl(GOOGLE_TOKEN_URL, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        assertion,
      }),
      signal: AbortSignal.timeout(10_000),
    });
    const body = await jsonOrError(response);
    if (!response.ok || !body.access_token) {
      throw new BillingError('STORE_UNAVAILABLE', 'Google Play authentication is unavailable', { retryable: true });
    }
    cachedAccessToken = body.access_token;
    accessTokenExpiresAt = timestamp + Math.max(60, Number(body.expires_in) || 3600) * 1000;
    return cachedAccessToken;
  }

  async function googleRequest(url, options = {}) {
    let token;
    try { token = await accessToken(); }
    catch (error) {
      if (error instanceof BillingError) throw error;
      throw new BillingError('STORE_UNAVAILABLE', 'Google Play authentication is unavailable', { retryable: true });
    }
    let response;
    try {
      response = await fetchImpl(url, {
        ...options,
        headers: { authorization: `Bearer ${token}`, ...(options.headers || {}) },
        signal: AbortSignal.timeout(10_000),
      });
    } catch {
      throw new BillingError('STORE_UNAVAILABLE', 'Google Play verification is temporarily unavailable', { retryable: true });
    }
    if (response.ok) return response;
    if (response.status === 404 || response.status === 400) {
      throw new BillingError('PURCHASE_INVALID', 'Google Play could not verify this purchase', { status: 400 });
    }
    if (response.status === 401 || response.status === 403) {
      cachedAccessToken = null;
      throw new BillingError('VERIFIER_NOT_CONFIGURED', 'Google Play verification is not authorized');
    }
    throw new BillingError('STORE_UNAVAILABLE', 'Google Play verification is temporarily unavailable', { retryable: true });
  }

  return {
    async verify({ packageName, productId, purchaseToken, expectedAccountId }) {
      const packagePart = encodeURIComponent(packageName);
      const tokenPart = encodeURIComponent(purchaseToken);
      const lookupUrl = `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${packagePart}/purchases/subscriptionsv2/tokens/${tokenPart}`;
      const lookup = await googleRequest(lookupUrl);
      const storeValue = await jsonOrError(lookup);
      const storeAccountId = storeValue.externalAccountIdentifiers?.obfuscatedExternalAccountId;
      if (expectedAccountId && storeAccountId !== expectedAccountId) {
        throw new BillingError('PURCHASE_OWNED', 'The purchase is not linked to this account', { status: 409 });
      }
      const normalized = normalizeGoogleSubscription(storeValue, { productId, now: now() });
      if (!normalized.purchase.acknowledged && normalized.purchase.state === 'purchased') {
        const productPart = encodeURIComponent(productId);
        const acknowledgeUrl = `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${packagePart}/purchases/subscriptions/${productPart}/tokens/${tokenPart}:acknowledge`;
        await googleRequest(acknowledgeUrl, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: '{}',
        });
        normalized.purchase.acknowledged = true;
      }
      return normalized;
    },
  };
}
