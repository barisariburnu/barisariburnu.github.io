# KUVVET Android Release Checklist

KUVVET is a branded Android distribution derived from openGym. Its permanent Android identity is
`com.gearapps.kuvvet` and its publisher website is `https://barisariburnu.com.tr`. The current
release candidate is signed and passes the local build gates. Publishing remains blocked only by
the external inputs listed below.

## Release blockers

- Publish the prepared public source archive and legal pages under
  `https://barisariburnu.com.tr/projects/kuvvet-app/`.
- Clear commercial rights for exercise images and animations, or replace/remove them. `NOTICE.md`
  records the upstream media provenance conflict and must ship with the release.
- Deploy a trusted HTTPS billing verifier, configure its Google Play service-account credential and
  create the `kuvvet_pro` subscription/base plans in Play Console.

## Signing status

- The local upload key was generated outside the repository and the release AAB was signed with it.
- `credentials.json` follows `credentials.example.json`, is ignored by Git and Docker, and has local
  owner-only permissions. It must never be committed or copied into the source archive.
- Enroll the upload certificate in Play App Signing during the first artifact upload and keep the
  recovery material outside GitHub.
- Release candidate: `kuvvet-1.0.0.aab` (`versionCode 1`, `versionName 1.0.0`).
- AAB SHA-256: `d0025663505990c8dc2ca1a8d6d9d4ad902693fe86d187cbc8c5409fac3f5dc4`.

## Product and billing inputs

| Item | Launch target |
|---|---|
| Product ID | `kuvvet_pro` |
| Android application ID | `com.gearapps.kuvvet` |
| Publisher website | `https://barisariburnu.com.tr` |
| Base plans | `monthly` (`P1M`), `annual` (`P1Y`) |
| Trial | 7 days for eligible new subscribers |
| US target | $1.99/month, $14.99/year |
| Turkey target | ₺14.99/month, ₺99.99/year |
| Free tier | All local workout logging, plans, history, import and export |
| Pro scope | Optional managed backup/sync and service-backed advanced analytics |

Google Play's store-returned `formattedPrice` is authoritative in the checkout UI. Pricing targets
must be rechecked in the Play Console before each release; taxes, store rounding and exchange-rate
changes can alter localized tiers.

## AdMob and app-ads.txt readiness

- The publisher's HTTPS file was verified at
  `https://barisariburnu.com.tr/app-ads.txt` on 2026-08-26.
- Verified public record: `google.com, pub-8939295877328751, DIRECT, f08c47fec0942fa0`.
- Set `https://barisariburnu.com.tr` as the developer website in the Play listing so AdMob can find
  the root-level file.
- Approved policy: the free tier may use only low-distraction adaptive banners on Library, Plan,
  and Stats. Home, active Workout, History, Settings, and Pro are ad-free; a verified Pro tier is
  ad-free everywhere. Interstitial, rewarded, and app-open ads are not part of the release plan.
- The public publisher ID is not an AdMob Android app ID. Before adding the Mobile Ads SDK, obtain
  the app ID shaped `ca-app-pub-...~...`, the required ad-unit IDs shaped `ca-app-pub-.../...`, and
  create the Privacy & Messaging configuration in AdMob.
- Do not commit Play Console or AdMob login email addresses, credentials, recovery codes,
  `google-services.json`, signing keys, or service-account keys to this repository.
- Integrate UMP before any ad request, expose privacy options when required, update Data safety and
  Privacy Policy disclosures, and use Google's dedicated test IDs/test devices before release.

## Play Console checklist

- Create the app using `com.gearapps.kuvvet`; verify the value before the first uploaded artifact
  because the Play application ID cannot be changed afterward.
- Complete Data safety from actual runtime behavior: local workout data is not purchase data;
  purchase tokens go only to the trusted verifier and are excluded from logs, backups and analytics.
- Upload phone screenshots captured from the English source locale, plus localized LTR screenshots
  where listing copy is localized. Do not declare or upload RTL locales.
- Configure internal testing before closed/open tracks. Add license testers and validate purchase,
  pending, restore, cancellation, grace, hold, expiry and revoke transitions.
- Verify acknowledgement and backend entitlement verification before moving beyond internal testing.
- Confirm the listing states that subscriptions fund optional services and that local workout data
  remains accessible after cancellation.
- Link Source, Privacy Policy, Terms and billing help from both the Play listing and in-app Settings;
  their canonical prefix is `https://barisariburnu.com.tr/projects/kuvvet-app/`.
- Attach the exact release tag/commit, reproducible build steps, AAB checksum and source-offer URL to
  the release record.

## Build gates

Run the checks in `specs/001-kuvvet-android-subscriptions/quickstart.md`. A release candidate needs:

- frontend and API tests passing;
- production web and mobile builds passing;
- Android Lint and unit tests passing;
- equal-viewport visual QA for the selected KUVVET reference;
- accessibility review for 48px touch targets, English fallback, supported LTR locales and reduced
  motion;
- no unresolved user-facing `openGym` branding other than compatibility/migration and upstream
  attribution disclosures.
