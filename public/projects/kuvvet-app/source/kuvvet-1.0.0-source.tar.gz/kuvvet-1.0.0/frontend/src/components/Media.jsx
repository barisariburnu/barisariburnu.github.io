import { useEffect, useState } from 'react'
import { imgSources, gifSources } from '../lib/exercises.js'
import { useStore } from '../store/useStore.js'
import { t, exerciseNameFor } from '../lib/i18n.js'
import Icon from './Icon.jsx'

// Big autoplaying animation; tap toggles to the still frame. `compact` shrinks it (superset cards).
// Custom exercises have no media — the animation stays blank by design (issue #11).
// `minimizable` (workout view) adds a persistent minimize/expand control so the animation stops
// eating the screen; the chosen size is saved to settings and carries across exercises and
// future workouts (issue #12).
export default function Media({ ex, id, compact, minimizable }) {
  const [playing, setPlaying] = useState(true)
  const gifSize = useStore(s => s.S.gifSize)
  const update = useStore(s => s.update)
  if (!ex.gif && !ex.img) return null
  const mini = minimizable && gifSize === 'mini'
  const toggleSize = e => { e.stopPropagation(); update(s => { s.gifSize = mini ? 'full' : 'mini' }) }
  const sources = playing ? [...gifSources(ex), ...imgSources(ex)] : imgSources(ex)
  return (
    <div className={'exmedia' + (compact ? ' compact' : '') + (mini ? ' mini' : '')} id={id} onClick={() => setPlaying(p => !p)}>
      <ResilientImage
        sources={sources}
        decoding="async"
        alt={exerciseNameFor(ex)}
        fallback={<MediaFallback compact={compact || mini} />}
      />
      {minimizable && (
        <button className="giftoggle" onClick={toggleSize}>
          <Icon name={mini ? 'expand' : 'minimize'} />{mini ? t('Expand') : t('Minimize')}
        </button>
      )}
      {!mini && (
        <span className="gifhint">
          <Icon name={playing ? 'pause' : 'play'} />{playing ? t('tap to pause') : t('tap to play')}
        </span>
      )}
    </div>
  )
}

export function Thumb({ ex }) {
  return <ResilientImage
    className="thumb"
    loading="lazy"
    decoding="async"
    sources={imgSources(ex)}
    alt=""
    fallback={<div className="thumb thumb-x"><Icon name="dumbbell" /></div>}
  />
}

function ResilientImage({ sources, fallback, ...props }) {
  const sourceKey = sources.join('\n')
  const [index, setIndex] = useState(0)
  useEffect(() => setIndex(0), [sourceKey])
  if (!sources[index]) return fallback
  return <img {...props} src={sources[index]} onError={() => setIndex(i => i + 1)} />
}

function MediaFallback({ compact }) {
  return <div className={'exmedia-fallback' + (compact ? ' compact' : '')}>
    <Icon name="dumbbell" />
    <span>{t('Media unavailable')}</span>
  </div>
}
