// @vitest-environment happy-dom
import React, { act } from 'react'
import { createRoot } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import Media, { Thumb } from './Media.jsx'

vi.mock('../lib/exercises.js', () => ({
  imgSources: ex => ex.img ? ['image-primary.jpg', 'image-fallback.jpg'] : [],
  gifSources: ex => ex.gif ? ['animation.gif'] : [],
}))
vi.mock('../store/useStore.js', () => ({
  useStore: selector => selector({ S: { gifSize: 'full' }, update: vi.fn() }),
}))
vi.mock('../lib/i18n.js', () => ({
  t: key => key,
  exerciseNameFor: ex => ex.n,
}))

globalThis.IS_REACT_ACT_ENVIRONMENT = true

let container
let root

beforeEach(() => {
  container = document.createElement('div')
  document.body.appendChild(container)
  root = createRoot(container)
})

afterEach(() => {
  act(() => root.unmount())
  container.remove()
})

const fail = image => act(() => image.dispatchEvent(new Event('error', { bubbles: true })))

describe('exercise media fallback', () => {
  it('tries every thumbnail source before showing the icon fallback', () => {
    act(() => root.render(<Thumb ex={{ img: 'exercise.jpg' }} />))
    expect(container.querySelector('img').getAttribute('src')).toBe('image-primary.jpg')

    fail(container.querySelector('img'))
    expect(container.querySelector('img').getAttribute('src')).toBe('image-fallback.jpg')

    fail(container.querySelector('img'))
    expect(container.querySelector('.thumb-x')).toBeTruthy()
  })

  it('falls back from animation to stills and then to localized empty media', () => {
    act(() => root.render(<Media ex={{ n: 'Squat', img: 'exercise.jpg', gif: 'exercise.gif' }} />))
    expect(container.querySelector('img').getAttribute('src')).toBe('animation.gif')

    fail(container.querySelector('img'))
    expect(container.querySelector('img').getAttribute('src')).toBe('image-primary.jpg')
    fail(container.querySelector('img'))
    fail(container.querySelector('img'))

    expect(container.querySelector('.exmedia-fallback').textContent).toContain('Media unavailable')
  })
})
