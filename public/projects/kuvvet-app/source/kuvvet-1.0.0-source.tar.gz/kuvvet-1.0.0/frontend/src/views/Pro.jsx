import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { t } from '../lib/i18n.js'
import {
  billingAccountReference,
  initializeBilling,
  listPlans,
  manageSubscription,
  onPurchaseUpdated,
  purchasePlan,
  refreshEntitlement,
  restorePurchases,
  verifyPurchases
} from '../lib/billing.js'
import { useUI } from '../store/useUI.js'
import { useStore } from '../store/useStore.js'
import Icon from '../components/Icon.jsx'
import BrandMark from '../components/BrandMark.jsx'

const TARGETS = {
  P1M: { usd: '$1.99', tr: '₺14.99', label: 'Monthly' },
  P1Y: { usd: '$14.99', tr: '₺99.99', label: 'Annual' }
}

export default function Pro() {
  const nav = useNavigate()
  const toast = useUI(s => s.toast)
  const user = useStore(s => s.user)
  const [plans, setPlans] = useState([])
  const [entitlement, setEntitlement] = useState(null)
  const [selected, setSelected] = useState('P1Y')
  const [available, setAvailable] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    let live = true
    let purchaseListener = null
    ;(async () => {
      if (user) {
        try {
          const current = await refreshEntitlement()
          if (live) setEntitlement(current)
        } catch { /* Offline or verifier unavailable: never invent Pro access. */ }
      }
      const init = await initializeBilling()
      if (!live || !init.available) return
      const result = await listPlans()
      if (live) { setPlans(result.plans || []); setAvailable(true) }
      purchaseListener = await onPurchaseUpdated(async update => {
        if (update.responseCode === 'USER_CANCELLED') return
        if (update.responseCode !== 'OK') return toast(t('Purchase verification failed. Please try Restore purchases.'))
        try {
          const verified = await verifyPurchases(update.purchases || [])
          if (live) setEntitlement(verified)
          toast(verified?.entitled ? t('KUVVET Pro is active.') : t('Purchase is not active yet.'))
        } catch (error) {
          toast(error.message || t('Purchase verification failed. Please try Restore purchases.'))
        }
      })
    })().catch(() => {})
    return () => { live = false; purchaseListener?.remove() }
  }, [toast, user])

  const storePlan = plans.find(p => p.billingPeriod === selected)
  const displayPrice = storePlan?.formattedPrice || (navigator.language?.startsWith('tr') ? TARGETS[selected].tr : TARGETS[selected].usd)
  const buy = async () => {
    if (!user) return toast(t('Connect this app to your account before subscribing.'))
    if (!available || !storePlan) return toast(t('Google Play checkout is available in the Android app.'))
    setBusy(true)
    try {
      const { obfuscatedAccountId } = await billingAccountReference()
      await purchasePlan({ ...storePlan, obfuscatedAccountId })
      toast(t('Complete your purchase in Google Play.'))
    }
    catch (e) { if (e.code !== 'USER_CANCELLED') toast(e.message || t('Purchase could not start.')) }
    finally { setBusy(false) }
  }
  const restore = async () => {
    if (!user) return toast(t('Connect this app to your account before restoring purchases.'))
    setBusy(true)
    try {
      const result = await restorePurchases()
      const verified = await verifyPurchases(result.purchases || [])
      setEntitlement(verified)
      toast(verified?.entitled ? t('KUVVET Pro is active.') : t('No active purchase was found.'))
    }
    catch (e) { toast(e.message || t('Restore failed.')) }
    finally { setBusy(false) }
  }

  return <main className="pro-page narrow">
    <header className="pro-head">
      <button className="iconbtn" onClick={() => nav('/settings')} aria-label={t('Settings')}><Icon name="chevronLeft" /></button>
      <BrandMark />
      <span className="pro-badge">PRO</span>
    </header>
    <div className="kuvvet-kicker">{t('Membership')}</div>
    <h1>{t('More service. Your training stays yours.')}</h1>
    <p className="pro-lead">{t('Local workout logging, plans, history and export remain free. Pro funds optional service-backed features.')}</p>
    {entitlement && <p className={`pro-status ${entitlement.entitled ? 'active' : ''}`}>
      {entitlement.entitled ? t('KUVVET Pro is active.') : t('Free plan is active.')}
    </p>}

    <ul className="pro-features">
      <li><Icon name="checkCircle" /><span><strong>{t('Private cloud backup')}</strong>{t('Recover your training data across supported devices.')}</span></li>
      <li><Icon name="checkCircle" /><span><strong>{t('Multi-device sync')}</strong>{t('Continue with the same history on your other devices.')}</span></li>
      <li><Icon name="checkCircle" /><span><strong>{t('Advanced service analytics')}</strong>{t('Deeper trends without locking your local history.')}</span></li>
    </ul>

    <div className="pro-plans">
      {Object.entries(TARGETS).map(([period, plan]) => (
        <button key={period} className={selected === period ? 'on' : ''} onClick={() => setSelected(period)}>
          <span>{t(plan.label)}{period === 'P1Y' && <em>{t('Best value')}</em>}</span>
          <strong>{plans.find(p => p.billingPeriod === period)?.formattedPrice || (navigator.language?.startsWith('tr') ? plan.tr : plan.usd)}<small>/{period === 'P1Y' ? t('year') : t('month')}</small></strong>
        </button>
      ))}
    </div>
    <button className="kuvvet-primary" onClick={buy} disabled={busy}><span>{t('Start 7-day free trial')}</span><Icon name="arrowRight" /></button>
    <p className="pro-note">{available ? t('Google Play shows the final localized price before confirmation.') : t('Target launch price: {0}. Google Play will show the final localized price.', displayPrice)}</p>
    <button className="kuvvet-text-action" onClick={restore} disabled={busy}>{t('Restore purchases')}</button>
    {entitlement?.entitled && <button className="kuvvet-text-action" onClick={() => manageSubscription()}>{t('Manage subscription')}</button>}
    <p className="pro-legal">
      {t('Cancel anytime in Google Play. Losing Pro never deletes or hides local workout data.')}{' '}
      <a href="https://barisariburnu.com.tr/projects/kuvvet-app/terms/" target="_blank" rel="noopener">{t('Terms')}</a>{' · '}
      <a href="https://barisariburnu.com.tr/projects/kuvvet-app/privacy/" target="_blank" rel="noopener">{t('Privacy')}</a>{' · '}
      <a href="https://barisariburnu.com.tr/projects/kuvvet-app/billing-help/" target="_blank" rel="noopener">{t('Billing help')}</a>
    </p>
  </main>
}
