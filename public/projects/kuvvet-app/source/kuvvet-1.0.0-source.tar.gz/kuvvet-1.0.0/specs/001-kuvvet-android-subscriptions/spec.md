# Feature Specification: KUVVET Android Rebrand and Subscriptions

**Feature Branch**: `main`

**Created**: 2026-08-26

**Status**: Draft

**Input**: User description: "Rebrand openGym as a minimal Android application, update its name
and logos, keep English as the primary language with Turkish and other major LTR languages, and
introduce a lower-cost subscription model."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Start Today's Workout Quickly (Priority: P1)

As a strength trainee, I open KUVVET and immediately understand today's training plan, my recent
progress, and the single action that starts or resumes my workout.

**Why this priority**: Fast workout entry is the product's daily core value and the selected design
direction is organized around this action.

**Independent Test**: Seed a user with a routine and recent data, open the home screen, and verify
that the user can start or resume today's workout with one obvious action without navigating away.

**Acceptance Scenarios**:

1. **Given** a planned workout for today, **When** the user opens KUVVET, **Then** the workout name,
   set progress, primary start action, latest body weight, and compact weekly summary are visible.
2. **Given** a workout is in progress, **When** the user returns to the home screen, **Then** the
   primary action resumes the active workout and shows completed versus total sets.
3. **Given** today is a rest day, **When** the user opens the home screen, **Then** the interface
   clearly communicates rest without presenting a misleading scheduled-workout action.
4. **Given** the user has no routines or history, **When** the user opens the home screen, **Then**
   the interface offers a direct starter-plan or plan-building path without empty charts.

---

### User Story 2 - Use KUVVET in an LTR Language (Priority: P2)

As an international user, I can use KUVVET in English by default or select another supported
left-to-right language while preserving my data and the minimal layout.

**Why this priority**: English-first international reach is a launch requirement, while Turkish
and the existing translated user base must remain supported.

**Independent Test**: Install with a clean state, confirm English is active, switch through every
listed language, and verify that navigation, the home screen, and settings remain usable.

**Acceptance Scenarios**:

1. **Given** a first launch with no saved language, **When** the app opens, **Then** all source UI
   appears in English.
2. **Given** a supported LTR language is selected, **When** the user navigates across primary
   screens, **Then** available translations appear and missing text falls back to English.
3. **Given** a translated label expands significantly, **When** it renders on a narrow Android
   screen, **Then** it wraps or truncates intentionally without hiding actions or navigation.
4. **Given** the language selector is opened, **When** the user reviews choices, **Then** no RTL
   language is offered in this release.

---

### User Story 3 - Subscribe to KUVVET Pro (Priority: P3)

As a user who wants managed cloud convenience, I can compare Pro plans, start a trial or
subscription through the device store, restore a purchase, and understand my current access state.

**Why this priority**: Subscription revenue supports the Android product, but local workout logging
must remain useful and private before monetization is introduced.

**Independent Test**: Use store test accounts to exercise purchase, cancellation, grace period,
on-hold, expiry, and restore paths while confirming that only valid purchases grant Pro service
access.

**Acceptance Scenarios**:

1. **Given** localized plans are available, **When** the user opens the Pro screen, **Then** the
   store-supplied price, period, trial, renewal, cancellation, privacy, and terms information appear.
2. **Given** a purchase is pending, **When** the store returns the pending state, **Then** the app
   shows a pending message and does not grant Pro benefits.
3. **Given** a purchase is verified as active, **When** the user returns to the app, **Then** Pro
   benefits are granted and the entitlement status is visible.
4. **Given** a subscription is cancelled but paid time remains, **When** status refreshes, **Then**
   access continues through the stated expiry date.
5. **Given** the subscription is on hold or expired, **When** status refreshes, **Then** service-only
   Pro benefits stop while local workout data and core logging remain available.
6. **Given** an existing subscriber reinstalls the app, **When** the user selects Restore purchase,
   **Then** a verified active entitlement is recovered without a duplicate charge.

---

### User Story 4 - Verify a Trustworthy Open-Source Release (Priority: P4)

As a prospective customer, I can see what data the app uses, where its source is offered, and which
features remain local before I install or subscribe.

**Why this priority**: Transparency is both a product differentiator and a distribution obligation.

**Independent Test**: Review the app's about/legal surfaces and release materials, follow the source
offer, export local data, and compare disclosed collection with observed behavior.

**Acceptance Scenarios**:

1. **Given** the user opens About or legal information, **When** they review licensing, **Then**
   KUVVET attribution, upstream attribution, AGPL terms, source access, privacy, and media notices
   are accessible.
2. **Given** a free user is offline, **When** they log and export workouts, **Then** the workflow
   completes without account creation, telemetry, or a subscription.
3. **Given** a user enables a Pro cloud service, **When** they review consent, **Then** data leaving
   the device, purpose, retention, deletion, and export behavior are explained beforehand.

---

### User Story 5 - View Reliable Exercise Guidance (Priority: P1)

As a trainee, I can see each built-in exercise thumbnail and animation in the Android app and demo,
and I receive a useful fallback instead of a broken image if media is temporarily unavailable.

**Independent Test**: Open the exercise library, verify representative thumbnails load, open an
exercise, verify its animation loads, then simulate a media failure and confirm the fallback state.

**Acceptance Scenarios**:

1. **Given** a demo or mobile build with network access, **When** the library opens, **Then** built-in
   thumbnails load from the immutable pinned media snapshot.
2. **Given** a built-in exercise is opened, **When** its animation is available, **Then** the GIF
   loads and can be toggled to the still image.
3. **Given** an image or animation fails, **When** all configured sources are exhausted, **Then** a
   localized media-unavailable state appears without breaking the list, sheet, or workout.

### Edge Cases

- The store is unavailable, returns no eligible offer, or reports that subscriptions are unsupported.
- A purchase callback is duplicated, arrives after app restart, or arrives before backend verification.
- The device is offline during purchase verification or entitlement refresh.
- The store price differs from the suggested launch price because of tax, exchange rates, or regional tiers.
- A user changes language during an active workout or while a purchase sheet is open.
- Existing persisted data contains the old product name in filenames or interoperability markers.
- The selected accent does not meet contrast in a light theme or high-contrast accessibility mode.
- The source offer or privacy-policy URL is unreachable at release-review time.
- Exercise media is offline, blocked, missing from the pinned snapshot, or fails midway through load.
- Consent is unavailable, withdrawn, or not yet collected when an otherwise eligible ad surface opens.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The product MUST present the name KUVVET and the approved geometric lime brand mark
  across the in-app header, launcher icon, installation metadata, and Android-facing name.
- **FR-002**: The home screen MUST use the approved graphite, off-white, and acid-lime design and
  prioritize today's workout as its single dominant action.
- **FR-003**: The primary action MUST start a planned workout, resume an active workout, or offer a
  clear plan/rest alternative appropriate to the user's current state.
- **FR-004**: The home screen MUST show only a compact set of supporting progress information and
  MUST avoid nested cards, promotional clutter, or social content.
- **FR-005**: English MUST be the default, source, and fallback language for all user-facing text.
- **FR-006**: The product MUST retain the currently supported LTR languages: German, Spanish, French,
  Italian, Portuguese (Portugal and Brazil), Polish, Turkish, Russian, Simplified Chinese, Korean,
  and Hindi.
- **FR-007**: The language selector MUST NOT offer RTL languages in this release.
- **FR-008**: Every new user-facing string MUST support translation without altering persisted
  training data or domain logic.
- **FR-009**: Core local planning, workout logging, history, body-weight tracking, export, and import
  MUST remain available without a subscription, account, telemetry, or network connection.
- **FR-010**: The product MUST offer monthly and annual Pro plans with store-localized prices and a
  seven-day introductory trial where the store and user eligibility allow it.
- **FR-011**: The Pro offer MUST target USD 1.99 monthly / USD 14.99 yearly and TRY 14.99 monthly /
  TRY 99.99 yearly, while displaying the store-returned price as authoritative.
- **FR-012**: Pro MUST be positioned around managed encrypted cloud backup, cross-device
  synchronization, and service-backed advanced analytics rather than removing core local logging.
- **FR-013**: The purchase surface MUST disclose price, period, trial terms, automatic renewal,
  cancellation route, restoration, privacy policy, and terms before launching store checkout.
- **FR-014**: Pro access MUST be granted only after trusted verification reports an active or
  grace-period entitlement.
- **FR-015**: Pending, on-hold, expired, refunded, revoked, and unverified purchases MUST NOT grant
  service-only Pro benefits.
- **FR-016**: Cancellation MUST preserve Pro access until the paid-through date, after which local
  data and core features MUST remain intact.
- **FR-017**: Users MUST be able to restore purchases and refresh entitlement state without buying
  again.
- **FR-018**: The release MUST expose AGPL source access, upstream attribution, privacy information,
  terms, and third-party media notices from an in-app legal surface.
- **FR-019**: The Android release identity MUST use an organization-controlled package namespace
  before production signing and MUST disable platform RTL mirroring for this LTR-only phase.
- **FR-020**: The visual design MUST support 48-pixel touch targets, reduced motion, system insets,
  screen widths from 320 to 600 CSS pixels, and WCAG 2.2 AA contrast for critical content.
- **FR-021**: Demo and Android builds MUST resolve built-in exercise images and animations from an
  immutable commit-pinned source; self-hosted web builds MUST remain local-first unless configured.
- **FR-022**: A failed exercise image or animation MUST fall through available sources and then
  render a localized non-broken fallback without interrupting workout logging.
- **FR-023**: Free-tier ads MAY appear only on the Library, Plan, and Stats surfaces in the native
  Android app; Home, active Workout, Pro, Settings, and History MUST remain ad-free.
- **FR-024**: A verified Pro entitlement MUST suppress every advertising placement.
- **FR-025**: No ad request may be made until a production AdMob app/ad-unit configuration exists
  and the native consent layer reports that ads may be requested; development MUST use Google test ads.

### Key Entities *(include if feature involves data)*

- **Brand Profile**: Product name, approved mark, colors, typography rules, launcher assets, and
  release-facing descriptions.
- **Locale Preference**: Selected supported language, English fallback behavior, and persistence
  across launches.
- **Subscription Product**: Store product identifier, base plan, billing period, localized price,
  eligible trial or offer, and display state.
- **Purchase Record**: Store purchase token reference, product, purchase state, acknowledgement
  state, verification timestamp, and non-sensitive account link.
- **Entitlement**: Free or Pro access, lifecycle state, paid-through time, last verification time,
  and service capabilities enabled.
- **Legal Disclosure**: Source offer, license and attribution references, privacy policy, terms,
  cancellation guidance, and media notices.
- **Ad Policy**: Eligible secondary surface, entitlement tier, Android-native state, configuration
  readiness, consent readiness, and the resulting allow/deny reason.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: At least 90% of first-time test participants can identify and start today's workout
  within 10 seconds and no more than one navigation action.
- **SC-002**: The home screen displays one dominant action and no more than two supporting progress
  regions at every supported phone width.
- **SC-003**: All supported language choices complete the primary home-to-workout flow without
  clipped controls, hidden navigation, or untranslated blocking text.
- **SC-004**: English appears on 100% of clean first launches and is used for 100% of missing
  translation fallbacks.
- **SC-005**: In store test scenarios, 100% of active and grace-period purchases grant Pro access,
  while 100% of pending, on-hold, expired, revoked, and unverified purchases do not.
- **SC-006**: A returning subscriber can restore verified access within 30 seconds when the store
  and network are available.
- **SC-007**: A user can log, finish, review, export, and restore a workout while offline without
  encountering an account or subscription gate.
- **SC-008**: All critical text and controls pass AA contrast checks, and all primary touch targets
  measure at least 48 by 48 CSS pixels.
- **SC-009**: Every distributed build provides working source, privacy, terms, attribution, and
  third-party notice links before release approval.
- **SC-010**: The first 40 library thumbnails and a representative exercise animation load with
  non-zero dimensions in demo and Android release-candidate checks.
- **SC-011**: Automated policy tests show zero eligible ads on Home, Workout, Pro, Settings, and
  History and zero eligible ads for Pro on every surface.

## Assumptions

- KUVVET is the selected product name and the first generated graphite/lime concept is the visual
  source of truth.
- Existing training data structures and import/export compatibility remain unchanged during rebrand.
- Existing LTR translation packs remain available; untranslated new copy falls back to English
  until translated.
- The Android application launches first; iOS publication and RTL support are out of scope.
- The publisher controls `barisariburnu.com.tr`; Android uses the publisher-selected permanent
  application ID `com.gearapps.kuvvet`. Google Play products, merchant profile and signing keys
  remain release-time Console inputs.
- Managed cloud services may reuse the existing synchronization architecture, but billing
  verification remains a trusted server responsibility.
- Suggested prices are launch targets; store-localized values and applicable taxes are authoritative.
- The free tier uses at most low-distraction adaptive banners on the three approved secondary
  surfaces; interstitial, rewarded, app-open, and active-workout advertising are out of scope.
